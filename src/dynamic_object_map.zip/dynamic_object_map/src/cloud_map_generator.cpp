#include <cmath>
#include <iomanip>
#include "transform/rigid_transform.h"
#include <common/common.h>
#include <nav_msgs/Odometry.h>
#include <opencv/cv.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/PointCloud2.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <fstream>
#include <list>
#include <glog/logging.h>

#include <pcl/visualization/point_cloud_color_handlers.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/console/parse.h>
#include <pcl/visualization/boost.h>
#include <pcl/visualization/mouse_event.h>
#include <pcl/sample_consensus/sac_model_perpendicular_plane.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/common/impl/angles.hpp>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/common/transforms.h>
#include <pcl/io/pcd_io.h>
#include <pcl/compression/octree_pointcloud_compression.h>   //
#include <pcl/octree/octree.h>

#include "StructMovingTargetDefine.h"
#include "MovingTargetTrack.h"
#include "util/boostudp/boostudp.h"
#include "common/blocking_queue.h"
#include "common/make_unique.h"
#include "src/velodyne/data_types.hpp"
#include "sensor_driver_msgs/OdometrywithGps.h"
#include "sensor_driver_msgs/GpswithHeading.h"

#include "iv_dynamicobject_msgs/moving_target.h"
#include "iv_dynamicobject_msgs/moving_target_send.h"
#include "iv_dynamicobject_msgs/Predict_traj.h"
#include "iv_dynamicobject_msgs/History_traj.h"
#include "iv_dynamicobject_msgs/Points.h"
#include "iv_dynamicobject_msgs/Rectangle.h"
#include "iv_dynamicobject_msgs/TargetCar.h"
#include "iv_dynamicobject_msgs/RadarPoint.h"
#include "iv_dynamicobject_msgs/RadarData.h"

#include "iv_dynamicobject_msgs/PolarCell.h"
#include "iv_dynamicobject_msgs/OGMCell.h"
#include "iv_dynamicobject_msgs/DynamicMap.h"

class PostProcess
{
public:
  typedef std::pair<double,transform::Rigid3d> TimePosePair;
  PostProcess(ros::NodeHandle& nodehandle):nodehandle_(nodehandle)
  ,processthread_(NULL)
  ,processthreadfinished_ (false)
  {
    init();
  }
  ~PostProcess()
  {
    lidarOdoms_.stopQueue();
    gpsdatas_.stopQueue();
    //ins_vel_data_.stopQueue();
    radardatas_.stopQueue();
    processthreadfinished_ = true;
    processthread_->join();
  }

  void init()
  {
    subLaserOdometry_ = nodehandle_.subscribe<sensor_driver_msgs::OdometrywithGps>
    ("lidar_odometry_to_earth", 5, boost::bind(&PostProcess::laserOdometryHandler,this,_1));//需要雷达里程计信息时需要，否则可以注释掉
    subLaserCloudFullRes_ = nodehandle_.subscribe<sensor_msgs::PointCloud2>
    ("lidar_cloud_calibrated", 1, boost::bind(&PostProcess::laserCloudHandler,this,_1));//经过筛选且转换之后的点云
    subGps_ = nodehandle_.subscribe<sensor_driver_msgs::GpswithHeading>
    ("gpsdata", 1, boost::bind(&PostProcess::gpsHandler,this,_1));//

    subRadar_ = nodehandle_.subscribe<iv_dynamicobject_msgs::RadarData>
    ("radardata", 1, boost::bind(&PostProcess::radarHandler,this,_1));//
    //subInsVel_ = nodehandle_.subscribe<sensor_driver_msgs::InsVelocity>
    // ("insvelocity", 1, boost::bind(&PostProcess::insvleHandler,this,_1));//


    processthread_ = new boost::thread(boost::bind(&PostProcess::process,this));

    pub_target_send = nodehandle_.advertise<iv_dynamicobject_msgs::moving_target_send>("MovingTarget",1);

    pub_show3D = nodehandle_.advertise<iv_dynamicobject_msgs::TargetCar>("Result",1);

    pub_dynamic_map_ = nodehandle_.advertise<iv_dynamicobject_msgs::DynamicMap>("dynamic_map",1);
  }


  //    void insvleHandler(const sensor_driver_msgs::InsVelocity::ConstPtr& ins_vel_msg_)
  //    {
  //        ins_vel_data_.Push(ins_vel_msg_);
  //    }
  void radarHandler(const iv_dynamicobject_msgs::RadarData::ConstPtr& radar_msg_)
  {
    radardatas_.Push(radar_msg_);
  }
  void gpsHandler(const sensor_driver_msgs::GpswithHeading::ConstPtr& gps)  //雷达里程计
  {
    //      ROS_INFO("<dynamicobject> GPS data callback...");
    gpsdatas_.Push(gps);
    //std::cout<<gps->gps.longitude<<std::endl;
  }

  void laserOdometryHandler(const sensor_driver_msgs::OdometrywithGps::ConstPtr& laserOdometry)
  {
    //      ROS_INFO("<dynamicobject> laserOdometryHandler data callback...");
    double timeOdometry = laserOdometry->odometry.header.stamp.toSec();
    static double last_stamp = -1;
    //  static geometry_msgs::Quaternion last_geoQuat;
    static transform::Rigid3d lasttransformodometry;
    //  static float last_trans[6];
    //  double roll, pitch, yaw;
    geometry_msgs::Quaternion geoQuat = laserOdometry->odometry.pose.pose.orientation;

    Eigen::Quaterniond roatation(geoQuat.w,geoQuat.x,geoQuat.y,geoQuat.z);
    Eigen::Vector3d translation(laserOdometry->odometry.pose.pose.position.x,
        laserOdometry->odometry.pose.pose.position.y,
        laserOdometry->odometry.pose.pose.position.z);

    transform::Rigid3d transformodometry(translation,roatation);
    lidarOdoms_.Push(common::make_unique<TimePosePair>(timeOdometry,transformodometry));
  }

  void laserCloudHandler(const sensor_msgs::PointCloud2ConstPtr& laserCloudFullRes2) //点云数据
  {
    //    ROS_INFO("<dynamicobject> laserOdometryHandler data callback...");
    double timeLaserCloudFullRes = laserCloudFullRes2->header.stamp.toSec();
    //LOG(INFO)<<std::fixed<<std::setprecision(3)<<"cloudtime:"<<timeLaserCloudFullRes;
    //LOG(INFO)<<"starttime"<<ros::Time::now().toSec() - timeLaserCloudFullRes;
    lidarCloudMsgs_.Push(laserCloudFullRes2);
    if(lidarCloudMsgs_.Size()>2)
      lidarCloudMsgs_.Pop();

  }

  void analysisCloud(pcl::PointCloud<pcl::PointXYZI>::Ptr inputcloud,
      std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr>& outputclouds,std::vector<pcl::PointXYZI>& lidarpropertys)
  {
    /////////总的点云中可能包含了几组独立的点云数据，对发过来的点云进行处理，将每一组点云都提取出来///////////
    int cloudnum = inputcloud->size() % 16;//包含的点云包数目
    vector<int> startnum;
    for(int i =0;i<cloudnum;i++)
    {
      pcl::PointXYZI originpoint;
      int flag = (*inputcloud)[inputcloud->size()-cloudnum+i].range;//每一包点云的第一个点的位置
      (*inputcloud)[inputcloud->size()-cloudnum+i].range = -0.5;
      originpoint.x = (*inputcloud)[inputcloud->size()-cloudnum+i].x;//每一包点云中对应的雷达在车体坐标系的x
      originpoint.y = (*inputcloud)[inputcloud->size()-cloudnum+i].y;////每一包点云中对应的雷达在车体坐标系的y
      originpoint.z = (*inputcloud)[inputcloud->size()-cloudnum+i].z;////每一包点云中对应的雷达在车体坐标系的z
      originpoint.intensity = (*inputcloud)[inputcloud->size()-cloudnum+i].azimuth;//每一包点云中对应的雷达线束
      startnum.push_back(flag);
      lidarpropertys.push_back(originpoint);
    }
    for(int i = 0;i < startnum.size();i++)
    {
      int length;
      pcl::PointCloud<pcl::PointXYZI>::Ptr lasercloudptr(new pcl::PointCloud<pcl::PointXYZI>);//每一包点云

      if(i == startnum.size()-1)
      {
        length = inputcloud->size() - cloudnum - startnum.at(i);
      }
      else
      {
        length = startnum.at(i+1) - startnum.at(i);
      }

      lasercloudptr->insert(lasercloudptr->begin(),inputcloud->begin()+startnum.at(i),inputcloud->begin()+startnum.at(i)+length);
      outputclouds.push_back(lasercloudptr);
    }
  }

  void analysisRadar(const iv_dynamicobject_msgs::RadarData::ConstPtr radar_msg_, Radar_data* radar_)
  {
    radar_->ACC_Target_ID = radar_msg_->ACC_Target_ID;
    radar_->target_num = 0;
    for (int i = 0; i < 64; ++i)
    {
      iv_dynamicobject_msgs::RadarPoint temp_radar_point = radar_msg_->delphi_detection_array[i];
      {
        Radar_Target temp_target;
        temp_target.time_stamp = radar_->time_stamp;
        temp_target.range = temp_radar_point.range;
        temp_target.angle = temp_radar_point.angle;
        temp_target.x = temp_radar_point.x;
        temp_target.y = temp_radar_point.y+4.0;
        temp_target.v = temp_radar_point.v;
        temp_target.v_x = temp_target.v*cos(temp_target.angle);
        temp_target.v_y = temp_target.v*sin(temp_target.angle);
        temp_target.moving = temp_radar_point.moving;
        temp_target.moving_fast = temp_radar_point.moving_fast;
        temp_target.moving_slow = temp_radar_point.moving_slow;
        temp_target.status = temp_radar_point.status;
        temp_target.valid = temp_radar_point.valid;
        temp_target.target_ID = temp_radar_point.target_ID;
        temp_target.match_index = -1;

        radar_->target[i] = temp_target;
        radar_->target_num++;
      }
    }
  }

  void Moving_target_out(iv_dynamicobject_msgs::moving_target* target_send_,  Target_output2 target_output_)
  {
    target_send_->line_num = target_output_.line_num;
    target_send_->line_point.clear();
    for (int i = 0; i < target_output_.line_num; ++i)
    {
      iv_dynamicobject_msgs::Points temp_point;
      temp_point.x = target_output_.line_point[i].x;
      temp_point.y = target_output_.line_point[i].y;
      temp_point.z = 0;
      target_send_->line_point.push_back(temp_point);
    }
    target_send_->center_point.x = target_output_.center_point.x;
    target_send_->center_point.y = target_output_.center_point.y;
    target_send_->center_point.z = 0;
    target_send_->object_high = target_output_.object_high;
    target_send_->object_type = target_output_.object_type;
    target_send_->ID_number = target_output_.ID_number;
    target_send_->is_updated = target_output_.is_updated;
    target_send_->tracked_times = target_output_.tracked_times;
    target_send_->dangerous_level = target_output_.dangerous_level;
    target_send_->predict_num = target_output_.predict_num;
    target_send_->predict_traj.clear();
    for (int i = 0; i < target_send_->predict_num; ++i)
    {
      //          std::cout<<"+++++++++++++++++++ "<<target_output_.predict_traj[i].point.x<<" "<<target_output_.predict_traj[i].point.y;
      iv_dynamicobject_msgs::Predict_traj temp_traj;
      temp_traj.time_stamp = target_output_.predict_traj[i].time_stamp;
      temp_traj.point.x = target_output_.predict_traj[i].point.x;
      temp_traj.point.y = target_output_.predict_traj[i].point.y;
      temp_traj.point.z = target_output_.predict_traj[i].time_stamp;
      temp_traj.v_x = target_output_.predict_traj[i].v_x;
      temp_traj.v_y = target_output_.predict_traj[i].v_y;
      temp_traj.acc_x = target_output_.predict_traj[i].acc_x;
      temp_traj.acc_y = target_output_.predict_traj[i].acc_y;
      temp_traj.pos_head = target_output_.predict_traj[i].pos_head;
      temp_traj.v_w = target_output_.predict_traj[i].v_w;
      temp_traj.confidence_level = target_output_.predict_traj[i].confidence_level;

      target_send_->predict_traj.push_back(temp_traj);
    }
    target_send_->history_num = target_output_.history_num;
    target_send_->history_traj.clear();
    for (int i = 0; i < target_send_->history_num; ++i)
    {
      iv_dynamicobject_msgs::History_traj temp_traj;
      temp_traj.time_stamp = target_output_.history_traj[i].history_time;
      temp_traj.center_point.x = target_output_.history_traj[i].history_center.x;
      temp_traj.center_point.y = target_output_.history_traj[i].history_center.y;
      temp_traj.center_point.z = 0;
      temp_traj.line_num = 4;
      temp_traj.line_point.clear();
      for (int j = 0; j < temp_traj.line_num; ++j)
      {
        iv_dynamicobject_msgs::Points temp_point;
        temp_point.x = target_output_.history_traj->history_rect.point4[j].x;
        temp_point.y = target_output_.history_traj->history_rect.point4[j].y;
        temp_point.z = 0;
        temp_traj.line_point.push_back(temp_point);
      }
      target_send_->history_traj.push_back(temp_traj);
    }
  }

  void ToPolarOGMMsg(iv_dynamicobject_msgs::PolarCell& polar_cell_msg,const Polar_Cell& polar_cell){
    polar_cell_msg.type = polar_cell.type;
    polar_cell_msg.intensity = polar_cell.intensity;
    polar_cell_msg.max_z = polar_cell.max_z;
    polar_cell_msg.min_z = polar_cell.min_z;
    polar_cell_msg.average_z = polar_cell.average_z;
    polar_cell_msg.delta_z = polar_cell.delta_z;

    polar_cell_msg.layers_num = polar_cell.layers_num;
    polar_cell_msg.points_num = polar_cell.points_num;
    polar_cell_msg.startlaser_index = polar_cell.startlaser_index;
    polar_cell_msg.endlaser_index = polar_cell.endlaser_index;
    polar_cell_msg.endpoint_index = polar_cell.endpoint_index;
    polar_cell_msg.startpoint_index = polar_cell.startpoint_index;

    polar_cell_msg.up_link = polar_cell.up_link;
    polar_cell_msg.down_link = polar_cell.down_link;
    polar_cell_msg.left_link = polar_cell.left_link;
    polar_cell_msg.right_link = polar_cell.right_link;

    polar_cell_msg.ground_z = polar_cell.ground_z;
    polar_cell_msg.ground_xy = polar_cell.ground_xy;
    polar_cell_msg.grad_m = polar_cell.grad_m;
    polar_cell_msg.grad_b = polar_cell.grad_b;
  }

  void ToGridOGMMsg(iv_dynamicobject_msgs::OGMCell& ogm_cell_msg,const OGM_Cell& ogm_cell){
    ogm_cell_msg.type = ogm_cell.type;
    ogm_cell_msg.intensity = ogm_cell.intensity;
    ogm_cell_msg.max_z = ogm_cell.max_z;
    ogm_cell_msg.min_z = ogm_cell.min_z;
    ogm_cell_msg.average_z = ogm_cell.average_z;
    ogm_cell_msg.delta_z = ogm_cell.delta_z;

    ogm_cell_msg.layers_num = ogm_cell.layers_num;
    ogm_cell_msg.points_num = ogm_cell.points_num;
    ogm_cell_msg.startlaser_index = ogm_cell.startlaser_index;
    ogm_cell_msg.endlaser_index = ogm_cell.endlaser_index;
    ogm_cell_msg.endpoint_index = ogm_cell.endpoint_index;
    ogm_cell_msg.startpoint_index = ogm_cell.startpoint_index;

    ogm_cell_msg.ground_z = ogm_cell.ground_z;
  }
  void SetViewerPCL(boost::shared_ptr<PCLVisualizer> cloud_viewer_)
  {
    cloud_viewer_->addCoordinateSystem (1.0);
    cloud_viewer_->setBackgroundColor(0,0,0);//(0.75,0.75,0.75);//(1.0,1.0,1.0);// (255, 0, 0);
    cloud_viewer_->initCameraParameters();
    cloud_viewer_->setCameraPosition(0.0, 0.0, 30.0, 0.0, 1.0, 0.0, 0);
    cloud_viewer_->setCameraClipDistances(1.0, 120.0);
  }


  void process()
  {
    frame_counter = 0;
    outputcloud_vector.clear();
    lidartime_vector.clear();

    while(!processthreadfinished_&&ros::ok())
    {
      timer t_total;
      frame_counter++;
      const sensor_msgs::PointCloud2ConstPtr cloudmsg = lidarCloudMsgs_.PopWithTimeout(common::FromSeconds(0.1));
      if(cloudmsg == nullptr)
      {
        //            ROS_INFO("Wait for data...");
        continue;
      }
      double lidartime = cloudmsg->header.stamp.toSec();

      pcl::PointCloud<pcl::PointXYZI>::Ptr tempcloud(new pcl::PointCloud<pcl::PointXYZI>);//当前帧点云（雷达里程计坐标系）
      pcl::fromROSMsg(*cloudmsg, *tempcloud);//获取当前帧点云数据
      std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> outputclouds;
      std::vector<pcl::PointXYZI> lidarpropertys;
      analysisCloud(tempcloud, outputclouds, lidarpropertys);
      //LOG(INFO)<<"cloud num:"<<lidarpropertys.size();
      //将获取的点云及时间戳存在向量里面,后面用来同步其他数据
      outputcloud_vector.push_back(tempcloud);
      lidartime_vector.push_back(lidartime);
      if (outputcloud_vector.size()>5)
      {
        outputcloud_vector.erase(outputcloud_vector.begin());
        lidartime_vector.erase(lidartime_vector.begin());
      }

      memset(&ego_veh_state_gps, 0, sizeof(State_Vehicle));
      memset(&ego_veh_state_lidar, 0, sizeof(State_Vehicle));
      ego_veh_state_gps.is_update = false;
      ego_veh_state_lidar.is_update = false;

      if (lidarOdoms_.Size()>0 && frame_counter >1)
      {
        auto timeposepair = lidarOdoms_.Pop();//需要雷达里程计信息时需要，否则可以注释掉
        while((timeposepair->first-lidartime)<-0.005)
          timeposepair = lidarOdoms_.Pop();
        if(timeposepair==nullptr)
          continue;
        if(timeposepair->first-lidartime>0.005) //如果雷达里程计时间晚于雷达点云时间，则跳到下一点云
        {
          lidarOdoms_.Push_Front(std::move(timeposepair));
          continue;
        }
        ego_veh_state_lidar.is_update = 1;
        //              std::cout<<"lidartime: "<<lidartime<<"odometry time: "<<timeposepair->first<<std::endl;
        Eigen::Vector3d translation=timeposepair->second.translation();
        Eigen::Vector3d angle = transform::toRollPitchYaw(timeposepair->second.rotation());

        if(ego_veh_state_lidar.is_update)
        {
          ego_veh_state_lidar.time_stamp = timeposepair->first;
          ego_veh_state_lidar.global_position.dLng = translation[0];
          ego_veh_state_lidar.global_position.dLat = translation[1];
          ego_veh_state_lidar.global_position.heading = 360 - angle[2]*180/pi;
          if(ego_veh_state_lidar.global_position.heading>=360)
            ego_veh_state_lidar.global_position.heading = ego_veh_state_lidar.global_position.heading - 360;
        }
      }

      //GPS信息同步
      if(gpsdatas_.Size()>0 && frame_counter>1)
      {
        sensor_driver_msgs::GpswithHeading::ConstPtr gpsdata;
        ego_veh_state_gps.is_update = 0;
        gpsdata = gpsdatas_.Pop();
        int temp_counter = 0;
        while(gpsdata->gps.header.stamp.toSec()-lidartime<-0.012)
        {
          if (gpsdatas_.Size()>0)
          {
            gpsdata = gpsdatas_.Pop();
            if(gpsdata->gps.header.stamp.toSec()-lidartime>-0.052)
              ego_veh_state_gps.is_update = 1;
          } else
          {
            break;
          }

          temp_counter++;
          if(temp_counter>100)
            break;
        }
        if(ego_veh_state_gps.is_update)
        {
          ego_veh_state_gps.time_stamp = gpsdata->gps.header.stamp.toSec();
          ego_veh_state_gps.fFLRWheelAverAngle =0;
          ego_veh_state_gps.fForwardVel = 0;
          ego_veh_state_gps.global_position.pitch = gpsdata->pitch;//俯仰角
          ego_veh_state_gps.global_position.roll = gpsdata->roll;//侧倾角
          ego_veh_state_gps.global_position.heading = 360 - gpsdata->heading;

          if(ego_veh_state_gps.global_position.heading>=360)
            ego_veh_state_gps.global_position.heading = ego_veh_state_gps.global_position.heading - 360;

          ego_veh_state_gps.global_position.dAld = 0;//gpsdata.;
          ego_veh_state_gps.global_position.dLat = gpsdata->gps.latitude;
          ego_veh_state_gps.global_position.dLng = gpsdata->gps.longitude;
          //                    printf("=======Lat: %.3f, Lng: %.3f\n",gpsdata->gps.latitude,gpsdata->gps.longitude);
          BaseFunction::Position_Trans_From_ECEF_To_UTM(gpsdata->gps.latitude, gpsdata->gps.longitude, 0,0,
              &ego_veh_state_gps.global_position.dLng, &ego_veh_state_gps.global_position.dLat);
          //                    printf("+++++++Lat: %.3f, Lng: %.3f\n",ego_veh_state_gps.global_position.dLat,ego_veh_state_gps.global_position.dLng);
        }
      }

      //毫米波雷达数据同步
      Radar_data radar_data;
      memset(&radar_data, 0, sizeof(Radar_data));
      radar_data.is_update = 0;
      if (radardatas_.Size()>0)
      {
        iv_dynamicobject_msgs::RadarData::ConstPtr radardata_msg;
        radardata_msg = radardatas_.Pop();
        int temp_counter = 0;
        while(radardata_msg->header.stamp.toSec()-lidartime<0.1)
        {
          if (radardatas_.Size()>0)
          {
            radardata_msg = radardatas_.Pop();
            if (radardata_msg->header.stamp.toSec()-lidartime>-0.052)
            {
              radar_data.is_update = 1;
            }
          } else
          {
            break;
          }

          temp_counter++;
          if(temp_counter > 100)
            break;
        }
        if (radar_data.is_update)
        {
          radar_data.time_stamp = radardata_msg->header.stamp.toSec();
          analysisRadar(radardata_msg, &radar_data);
        }
      }

      //为moving_target对象成员变量赋值
      moving_target.radar = radar_data;
      moving_target.time_stamp = lidartime;//以激光雷达时间戳作为动态目标分析时间戳
      moving_target.ego_veh_state_gps = ego_veh_state_gps;
      moving_target.ego_veh_state_lidar = ego_veh_state_lidar;

//      moving_target.ego_veh_state_current = ego_veh_state_gps;//最终使用的就是这个
      moving_target.ego_veh_state_current = ego_veh_state_lidar;//最终使用的就是这个
      std::cout<<"========================= Begin Process============================"<<std::endl;
      static double time_pre_ = lidartime;
      double delta_t = lidartime - time_pre_;
      time_pre_ = lidartime;
      std::cout<<"delta_t---------------------------- "<<delta_t<<endl;//TODO:查看雷达数据延时情况,最好显示出来
      if(tempcloud->points.size()&& moving_target.ego_veh_state_current.is_update  && frame_counter>1){
        //开始处理
        moving_target.SetCloudInput(tempcloud);
        moving_target.ProcessFrame();

        //获得生成的栅格地图
        int polarogm_cell_size,refineogmcell_size;
        const Polar_Cell* polar_ogm = moving_target.get_polar_ogm(polarogm_cell_size);
        const OGM_Cell* rigid_refined_ogm = moving_target.get_rigid_refined_ogm(refineogmcell_size);
        const IplImage* img_ogm = moving_target.get_img_ogm();

        //ROS消息发送
        iv_dynamicobject_msgs::PolarCell polar_ogm_msgs;
        iv_dynamicobject_msgs::OGMCell ogm_cell_msgs;
        iv_dynamicobject_msgs::DynamicMap dynamic_map_send;
        for(int i = 0;i<polarogm_cell_size;++i){//遍历polar栅格地图
          ToPolarOGMMsg(polar_ogm_msgs,polar_ogm[i]);
          dynamic_map_send.polar_ogm.push_back(polar_ogm_msgs);
        }
        for(int i = 0;i < refineogmcell_size;++i){//遍历ogm栅格地图
          ToGridOGMMsg(ogm_cell_msgs,rigid_refined_ogm[i]);
          dynamic_map_send.rigid_refined_ogm.push_back(ogm_cell_msgs);
        }
        dynamic_map_send.header.stamp = cloudmsg->header.stamp;//应该发送雷达的时间,用来和里程计同步,剔除预处理过程耗时？TODO
        pub_dynamic_map_.publish(dynamic_map_send);
//        moving_target.Show_Result_2D(t_total.elapsed());,
      }
      else{//出错检查
        double delta_time = lidartime;
        int lidar_update = 1;
        if(tempcloud->points.size()<1)
          lidar_update = 0;
        int ego_update = 1;
        if(!moving_target.ego_veh_state_current.is_update)
          ego_update = 0;
        std::cout<<"lidartime "<<setprecision(13)<< lidartime<<"  lidartime "<<setprecision(13)<< lidartime<<std::endl;
        std::cout<<"lidarupdate "<< lidar_update<<"  egoupdate "<< ego_update<<std::endl;
      }

      std::cout<< "-------------------- t_total: " << t_total.elapsed() << endl;
      std::cout<<"========================= End Process============================"<<std::endl<<std::endl<<std::endl;
    }//end while(!processthreadfinished_)
  }

protected:

  ros::Subscriber subLaserCloudFullRes_ ;//经过筛选且转换之后的点云
  ros::Subscriber subLaserOdometry_ ;
  ros::Subscriber subGps_ ;//经过筛选且#include "sensor_driver_msgs/moving_target.h"转换之后的点云
  ros::Subscriber subRadar_ ;
  ros::Subscriber subInsVel_ ;

  ros::Publisher pub_target_send;
  ros::Publisher pub_show3D;
  ros::Publisher pub_dynamic_map_;

  common::BlockingQueue<sensor_msgs::PointCloud2ConstPtr> lidarCloudMsgs_;
  common::BlockingQueue<std::unique_ptr<TimePosePair>> lidarOdoms_;
  common::BlockingQueue<sensor_driver_msgs::GpswithHeading::ConstPtr> gpsdatas_;
  //common::BlockingQueue<sensor_driver_msgs::InsVelocity::ConstPtr> ins_vel_data_;
  common::BlockingQueue<iv_dynamicobject_msgs::RadarData::ConstPtr> radardatas_;
  //  std::fstream file_;
  ros::NodeHandle& nodehandle_;
  boost::thread* processthread_;
  bool processthreadfinished_;

  //    boost::shared_ptr<PCLVisualizer> cloud_viewer_;
  //    pcl::visualization::CloudViewer viewer_;



  State_Vehicle ego_veh_state_current;
  State_Vehicle ego_veh_state_lidar;
  State_Vehicle ego_veh_state_gps;
  dynamic_map::MovingTargetTrack moving_target;

  std::vector<double> lidartime_vector;
  std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> outputcloud_vector;
  int frame_counter;
};


int main(int argc, char** argv)
{
  ros::init(argc, argv, "dynamicobject");
  ros::NodeHandle nh;

  google::ParseCommandLineFlags(&argc, &argv, true);
  google::InitGoogleLogging(argv[0]);
  google::InstallFailureSignalHandler();
  FLAGS_colorlogtostderr = true; //设置输出到屏幕的日志显示相应颜色
  PostProcess postprocess(nh);
  ros::spin();


  return 0;
}
