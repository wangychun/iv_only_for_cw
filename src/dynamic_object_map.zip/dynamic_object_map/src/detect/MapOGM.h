#pragma once

#include <cv.h>
#include <highgui.h>
#include <cxcore.h>
#include <vector>
#include <iostream>
#include "../StructMovingTargetDefine.h"
#include "../ShowResult.h"
using namespace std;

class OGMMappingUtils
{
public:
    OGMMappingUtils();
	~OGMMappingUtils();

    int value_in_threshod_int(int value_, int threshod_pre_, int threshod_up_);
    int Laser_index2channal(int laser_num_, int index_);

	void PolarOGM_Ground_first(Polar_Cell* polar_ogm_, Line_s* polar_fit_line_, float polar_angle_, float polar_radius_,
                               float polar_angle_resolution_, float polar_radius_resolution_,
							   OGM_Cell* rigid_ogm_, float ogmwidth_, float ogmheight_ , float ogmresolution_, float offest_y_ );
    void PolarOGM_Ground(Polar_Cell* polar_ogm_, Line_s* polar_fit_line_,float polarogm_angle_, float polarogm_radius_,
						 float polarogm_angle_resolution_, float polarogm_radius_resolution_,
						 Polar_Cell* largepolar_ogm_, float largepolarogm_angle_, float largepolarogm_radius_,
						 float largepolarogm_angle_resolution_, float largepolarogm_radius_resolution_);
    //给栅格地图cell赋予type属性,UNKNOWN,RIGIDNOPASSABLE etc.
	void GridOGM_Ground(Polar_Cell* polar_ogm_, float polarogm_angle_, float polarogm_radius_,float polarogm_angle_resolution_, float polarogm_radius_resolution_,
						 OGM_Cell* rigid_ogm_, float ogm_width_, float ogm_height_ , float ogm_resolution_, float offest_y_ );

	//将点云投影直角坐标栅格
	void CloudLser2GridOGM( pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_all_, int laserscanner_num_,
							int startlaser_index_, int endlaser_index_, OGM_Cell* rigid_ogm_, float ogmwidth_,
							float ogmheight_ , float ogmresolution_, float offest_y_);
	//将点云投影成极坐标栅格
	void CloudLser2PolarOGM( pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_all_, int laserscanner_num_, int polar_ogm_method_,
							 int startlaser_index_, int endlaser_index_, Polar_Cell* polar_ogm_,
							 float polarogm_angle_, float polarogm_radius_,float polarogm_angle_resolution_, float polarogm_radius_resolution_ );


    int map_width;
    int map_height;
    int map_offset_y;
    float map_resolution;
    CvPoint ego_veh_position;
    int frame_counter;

	ShowResult show_result;


protected:


private:
};
