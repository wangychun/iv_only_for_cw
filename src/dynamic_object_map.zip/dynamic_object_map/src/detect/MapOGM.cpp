#include "MapOGM.h"
#include "../StructMovingTargetDefine.h"

OGMMappingUtils::OGMMappingUtils()
{
    frame_counter = 0;
}
OGMMappingUtils::~OGMMappingUtils()
{
}
//********************************//
int OGMMappingUtils::value_in_threshod_int(int value_, int threshod_pre_, int threshod_up_)
{
    int value_return = value_;
    int threshod_length = threshod_up_ - threshod_pre_ + 1;

    if (value_ < threshod_pre_)
    {
        value_return = value_ + threshod_length;
    }
    if (value_ > threshod_up_)
    {
        value_return = value_ - threshod_length;
    }

    return value_return;
}
int OGMMappingUtils::Laser_index2channal(int laser_num_, int laser_index_)
{
    int laser_channal_ = 0;
    if (laser_num_ == 32)
    {

        if (laser_index_< 16)
        {
            laser_channal_ = laser_index_*2;
        }
        else
        {
            laser_channal_ = laser_index_*2-31;
        }
    }
    if (laser_num_ == 64)
    {
        int temp_index = laser_index_;
        if (laser_index_>31)
        {
            temp_index = laser_index_ - 32;
        }
        switch(temp_index)
        {
            case 0: laser_channal_ = 38;break;
            case 1: laser_channal_ = 39;break;
            case 2: laser_channal_ = 42;break;
            case 3: laser_channal_ = 43;break;
            case 4: laser_channal_ = 32;break;
            case 5: laser_channal_ = 33;break;
            case 6: laser_channal_ = 36;break;
            case 7: laser_channal_ = 37;break;
            case 8: laser_channal_ = 40;break;
            case 9: laser_channal_ = 41;break;
            case 10: laser_channal_ = 46;break;
            case 11: laser_channal_ = 47;break;
            case 12: laser_channal_ = 50;break;
            case 13: laser_channal_ = 51;break;
            case 14: laser_channal_ = 54;break;
            case 15: laser_channal_ = 55;break;
            case 16: laser_channal_ = 44;break;
            case 17: laser_channal_ = 45;break;
            case 18: laser_channal_ = 48;break;
            case 19: laser_channal_ = 49;break;
            case 20: laser_channal_ = 52;break;
            case 21: laser_channal_ = 53;break;
            case 22: laser_channal_ = 58;break;
            case 23: laser_channal_ = 59;break;
            case 24: laser_channal_ = 62;break;
            case 25: laser_channal_ = 63;break;
            case 26: laser_channal_ = 34;break;
            case 27: laser_channal_ = 35;break;
            case 28: laser_channal_ = 56;break;
            case 29: laser_channal_ = 57;break;
            case 30: laser_channal_ = 60;break;
            case 31: laser_channal_ = 61;break;
            default:break;
        }
        if (laser_index_>31)
        {
            laser_channal_ = laser_channal_ - 32;
        }
    }
    return laser_channal_;
}
//**********************************//
void OGMMappingUtils::CloudLser2GridOGM( pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_all_, int laserscanner_num_,
                                           int startlaser_index_, int endlaser_index_, OGM_Cell* rigid_ogm_,
                                           float ogmwidth_, float ogmheight_, float ogmresolution_, float ogm_offset_y_)
{
  //根据米制单位地图和分辨率计算栅格图像尺寸
    int ogmwidth_cell_ = boost::math::round( ogmwidth_/ ogmresolution_)+1;
    int ogmheight_cell_ = boost::math::round( ogmheight_/ ogmresolution_)+1;

    for (int i = 0; i < cloud_all_->points.size(); ++i)//遍历点云
    {
      int point_id = i;
      //获得每个点的属性
      float x = cloud_all_->points[point_id].x;
      float y = cloud_all_->points[point_id].y;
      float z = cloud_all_->points[point_id].z;
      int	intensity = cloud_all_->points[point_id].intensity;

      if (!(fabs(x)<1.5 && y<4.5&& y>-10) && z <Z_MAX &&  z >Z_MIN)//只考虑这个范围内的点云
      {
        float newy = y + ogm_offset_y_ - V_OFFSET_Y;//TODO:V_OFFSET_Y是什么含义？
        if ( x>=-ogmwidth_/2 && x<ogmwidth_/2  && newy>=0 && newy<ogmheight_)
        {
          int col = (int)((x + ogmwidth_/2) / ogmresolution_);
          int row = (int)(newy / ogmresolution_) ;
          int index = row * ogmwidth_cell_ + col;

          if(row >=0 && row < ogmheight_cell_ && col >=0 && col < ogmwidth_cell_)
          {
            rigid_ogm_[index].min_z = min(z, rigid_ogm_[index].min_z);
            rigid_ogm_[index].max_z = max(z, rigid_ogm_[index].max_z);
            rigid_ogm_[index].intensity = max(intensity, rigid_ogm_[index].intensity);

            rigid_ogm_[index].points_num++;
            //一个栅格中的点云平均高度
            rigid_ogm_[index].average_z = ( rigid_ogm_[index].average_z*(rigid_ogm_[index].points_num-1) + z )
                                                          / rigid_ogm_[index].points_num;
            //即该帧点云中符合条件的点的最大索引值
            rigid_ogm_[index].endpoint_index = max(i, rigid_ogm_[index].endpoint_index);
            //即该帧点云中符合条件的点的最小索引值
            rigid_ogm_[index].startpoint_index = min(i, rigid_ogm_[index].startpoint_index);
            rigid_ogm_[index].endlaser_index = 0;//max(laser_index, rigid_ogm_[index].endlaser_index);
            rigid_ogm_[index].startlaser_index = 0;//min(laser_index, rigid_ogm_[index].startlaser_index);

            rigid_ogm_[index].layers_num = rigid_ogm_[index].endlaser_index -
                rigid_ogm_[index].startlaser_index + 1;
            //一个栅格中点云的最大高度差
            rigid_ogm_[index].delta_z = rigid_ogm_[index].max_z - rigid_ogm_[index].min_z;
            rigid_ogm_[index].type = UNIDENTIFY;

          }
        }
      }
    }
}

void OGMMappingUtils::CloudLser2PolarOGM( pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_all_, int laserscanner_num_, int polar_ogm_method_,
                                  int startlaser_index_, int endlaser_index_, Polar_Cell* polar_ogm_, float polarogm_angle_,
                                  float polarogm_radius_,float polarogm_angle_resolution_, float polarogm_radius_resolution_ )
{
    int polarlaser_max = endlaser_index_;
    int cloudpoint_num = cloud_all_->points.size();
    int laserpoint_num = (int)(cloud_all_->points.size() / laserscanner_num_);

    int polarogm_angle_cell_ = boost::math::round( polarogm_angle_ / polarogm_angle_resolution_ );
    int polarogm_radius_cell_ = boost::math::round( polarogm_radius_ / polarogm_radius_resolution_);

    if (1)
    {
        //for (int laser_index = 0; laser_index < endlaser_index_; laser_index++)//
        {
            //int laser_channal = Laser_index2channal(laserscanner_num_, laser_index);

            //for (int i = 0; i < laserpoint_num; i++)
            for (int i = 0; i < cloud_all_->points.size(); i++)
            {
                int point_id = i;//i * laserscanner_num_ + laser_channal;

                float x = cloud_all_->points[point_id].x;
                float y = cloud_all_->points[point_id].y;
                float z = cloud_all_->points[point_id].z;
                int	intensity = cloud_all_->points[point_id].intensity;

                float new_y = y - V_OFFSET_Y;
                float azimuth = BaseFunction::Angle_atan2( x, new_y);
                float dis_xy = sqrt(x*x + new_y*new_y);

                if ( !(x<1.5 && x>-1.5 && y<4.5 && y>-10) && z <Z_MAX &&  z >Z_MIN
                     && azimuth >= 0 && azimuth < 360 && dis_xy>1.0 && dis_xy<polarogm_radius_)
                {


                    int angle_col = (int)(azimuth / polarogm_angle_resolution_);
                    int radius_row = (int)(dis_xy / polarogm_radius_resolution_);

                    if(radius_row >=0 && radius_row < polarogm_radius_cell_ && angle_col >=0 && angle_col < polarogm_angle_cell_)
                    {
                        int index = radius_row * polarogm_angle_cell_ + angle_col;

                        polar_ogm_[index].min_z = min(z, polar_ogm_[index].min_z);
                        polar_ogm_[index].max_z = max(z, polar_ogm_[index].max_z);
                        polar_ogm_[index].intensity = max(intensity, polar_ogm_[index].intensity);


                        polar_ogm_[index].points_num++;
                        polar_ogm_[index].average_z = ( polar_ogm_[index].average_z * (polar_ogm_[index].points_num-1)
                                                        + z )/ polar_ogm_[index].points_num;
                        polar_ogm_[index].ground_xy = ( polar_ogm_[index].ground_xy * (polar_ogm_[index].points_num-1)
                                                        + dis_xy )/ polar_ogm_[index].points_num;

                        polar_ogm_[index].endpoint_index = max(i, polar_ogm_[index].endpoint_index);
                        polar_ogm_[index].startpoint_index = min(i, polar_ogm_[index].startpoint_index);
                        polar_ogm_[index].endlaser_index = 0;//max(laser_index, polar_ogm_[index].endlaser_index);
                        polar_ogm_[index].startlaser_index = 0;//min(laser_index, polar_ogm_[index].startlaser_index);

                        polar_ogm_[index].delta_z = polar_ogm_[index].max_z - polar_ogm_[index].min_z;
                        polar_ogm_[index].layers_num = polar_ogm_[index].endlaser_index
                                                       - polar_ogm_[index].startlaser_index +1;
                        polar_ogm_[index].type = UNIDENTIFY;
                    }
                }
            }
        }
    }
}

//***************************** cloud segment ***********************//
void OGMMappingUtils::PolarOGM_Ground_first(Polar_Cell* polar_ogm_, Line_s* polar_fit_line_, float polar_angle_, float polar_radius_,
                                    float polar_angle_resolution_, float polar_radius_resolution_,
                                    OGM_Cell* rigid_ogm_, float ogmwidth_, float ogmheight_ , float ogmresolution_, float offest_y_ )
{
    int rigid_width_cell = boost::math::round(ogmwidth_ / ogmresolution_ )+1;
    int rigid_height_cell = boost::math::round(ogmheight_ / ogmresolution_)+1;
    int offfest_y = boost::math::round(offest_y_ / ogmresolution_);

    int polar_angle_cell = boost::math::round(polar_angle_ / polar_angle_resolution_ );
    int polar_radius_cell = boost::math::round(polar_radius_ / polar_radius_resolution_);
    int polar_cell_size_ = polar_radius_cell* polar_angle_cell;

    CvPoint ego_position = cvPoint(rigid_width_cell/2, offfest_y);
    int polarogm_radius_first = boost::math::round( 20 / polar_radius_resolution_);

    int* is_find_groundradius = new int[polar_angle_cell];
    memset(is_find_groundradius, 0, polar_angle_cell*sizeof(int));

    int* groundradius_index_first = new int[polar_angle_cell];
    memset(groundradius_index_first, 0, polar_angle_cell*sizeof(int));
    if (1)
    {
        ego_position.x = rigid_width_cell/2;
        ego_position.y = offfest_y;
        for (int i=ego_position.y - 5/ogmresolution_; i<(ego_position.y + 5/ogmresolution_); i++)
        {
            for (int j=ego_position.y - 5/ogmresolution_; j<(ego_position.y + 5/ogmresolution_); j++)
            {
                int rigid_index = i*rigid_width_cell + j;
                if (rigid_ogm_[rigid_index].type == UNIDENTIFY)
                {
                    if (rigid_ogm_[rigid_index].delta_z<0.35)
                    {
                        rigid_ogm_[rigid_index].type = GROUND;
                    } else
                    {
                        rigid_ogm_[rigid_index].type = RIGIDNOPASSABLE;
                    }
                }
            }
        }
        int i_start = (int)(270/polar_angle_resolution_);
        for (int ii = 0; ii < polar_angle_cell; ++ii)
        {
            int i = value_in_threshod_int(i_start+ii, 0, polar_angle_cell-1);
            float ground_z = 0;
            int j_pre = 0;
            int index_pre = j_pre * polar_angle_cell + i;
            bool is_break = false;
            for (int j = 2; j < 10 / polar_radius_resolution_;)
            {
                int polar_index = j * polar_angle_cell + i;
                index_pre = j_pre * polar_angle_cell + i;
                int j_up = j + 1;
                int index_up = j_up * polar_angle_cell + i;
                int temp_counter = 0;
                bool is_up = false;
                while (temp_counter < 6 && j_up < polar_radius_cell)
                {
                    index_up = j_up * polar_angle_cell + i;
                    if (polar_ogm_[index_up].type == UNIDENTIFY)
                    {
                        is_up = true;
                        break;
                    }
                    temp_counter++;
                    j_up++;
                }
                if (polar_ogm_[polar_index].type == UNIDENTIFY)
                {
                    ground_z = ground_z + polar_ogm_[index_pre].grad_m*(j-j_pre)*polar_radius_resolution_;
                    float delta_ground_z = polar_ogm_[polar_index].min_z - ground_z;
                    if (is_find_groundradius[i] > 0)
                    {
                        is_find_groundradius[i] = j;
                        ground_z = polar_ogm_[polar_index].min_z;
                        if (polar_ogm_[polar_index].delta_z < 0.35 && fabs(delta_ground_z)<0.35)
                            ground_z = polar_ogm_[polar_index].average_z;

                    } else
                    {
                        is_find_groundradius[i] = j;
                        ground_z = polar_ogm_[polar_index].min_z;
                        if(is_find_groundradius[i]>0)
                        {
                            polar_ogm_[polar_index].grad_b = j*polar_radius_resolution_;
                            polar_ogm_[polar_index].grad_m = ground_z;
                            for (int k = 1; k < is_find_groundradius[i]; ++k)
                            {
                                int temp_index1 = k*polar_angle_cell + i;
                                polar_ogm_[polar_index].ground_z = ground_z*k/j;
                                polar_ogm_[temp_index1].grad_b =  polar_ogm_[polar_index].grad_b;
                                polar_ogm_[temp_index1].grad_m = ground_z*k/j;
                            }
                        }
                    }

                    polar_ogm_[polar_index].grad_b = (j - j_pre)*polar_radius_resolution_;
                    polar_ogm_[polar_index].grad_m = (ground_z - polar_ogm_[index_pre].ground_z)/polar_ogm_[polar_index].grad_b;
                    polar_ogm_[polar_index].ground_z = ground_z;
                    is_find_groundradius[i] = j;
                    j_pre = j;

                    if(polar_ogm_[polar_index].delta_z < 0.35)
                    {
                        polar_ogm_[polar_index].type = GROUND;
                    } else
                    {
                        polar_ogm_[polar_index].type = RIGIDNOPASSABLE;
                        if (is_up)
                            polar_ogm_[polar_index].type = PASSABLE;
                    }

                    if (!is_up)
                    {
                        break;
                    }
                    if (is_up)
                    {
                        float groun_z_up = ground_z + polar_ogm_[polar_index].grad_m*(j_up-j)*polar_angle_resolution_;
                        float delta_ground_z_up = polar_ogm_[index_up].min_z - groun_z_up;
                        float delta_z_up = polar_ogm_[index_up].min_z - polar_ogm_[polar_index].max_z;
                        float delta_z_sum = delta_ground_z_up + delta_z_up;
                        if (polar_ogm_[polar_index].delta_z > 0.5 && fabs(delta_ground_z_up) > 0.5)
                        {
                            break;
                        }
                    }
                }
                j = j_up;
            }
        }
    }

    if (0)
    {
        ego_position.x = rigid_width_cell/2;
        ego_position.y = offfest_y;
        for (int i=0; i<polar_angle_cell; i++)
        {
            float temp_angle = (i+0.5)*polar_angle_resolution_ * pi / 180;
            for (int j = 1/ogmresolution_; j < 10/ogmresolution_; ++j)
            {
                CvPoint2D32f temp_point_f;
                temp_point_f.x = ego_veh_position.x + (j+0.5)*cos(temp_angle);
                temp_point_f.y = ego_veh_position.y - (j+0.5)*sin(temp_angle);
                CvPoint temp_point = cvPointFrom32f(temp_point_f);
                int rigid_index = temp_point.y *rigid_width_cell + temp_point.x;
                if (rigid_ogm_[rigid_index].type == UNIDENTIFY)
                {
                    int r_index = (j+0.5)*ogmresolution_/polar_radius_resolution_;
                    int polar_index = r_index*polar_angle_cell + i;
                    is_find_groundradius[i] = r_index;
                    if (rigid_ogm_[rigid_index].delta_z < 0.35)
                    {
                        rigid_ogm_[rigid_index].ground_z = rigid_ogm_[rigid_index].average_z;
                        rigid_ogm_[rigid_index].type = GROUND;
                        polar_ogm_[polar_index].ground_z = rigid_ogm_[rigid_index].ground_z;
                        if (polar_ogm_[polar_index].type == RIGIDNOPASSABLE)
                        {
                            polar_ogm_[polar_index].type = PASSABLE;;
                        } else
                        {
                            polar_ogm_[polar_index].type = GROUND;;
                        }
                    } else
                    {
                        rigid_ogm_[rigid_index].ground_z = rigid_ogm_[rigid_index].min_z;
                        rigid_ogm_[rigid_index].type = RIGIDNOPASSABLE;
                        polar_ogm_[polar_index].ground_z = rigid_ogm_[rigid_index].ground_z;
                        polar_ogm_[polar_index].type = PASSABLE;
                        break;
                    }
                }
            }
        }
//        int i_start = (int)(270/polar_angle_resolution_);
//        for (int ii = 0; ii < polar_angle_cell; ++ii)
//        {
//            int i = value_in_threshod_int(i_start+ii, 0, polar_angle_cell-1);
//            float ground_z = 0;
//            int j_pre = 0;
//            int index_pre = j_pre * polar_angle_cell + i;
//            bool is_break = false;
//            for (int j = 2; j < 10 / polar_radius_resolution_;)
//            {
//                int polar_index = j * polar_angle_cell + i;
//                index_pre = j_pre * polar_angle_cell + i;
//                int j_up = j + 1;
//                int index_up = j_up * polar_angle_cell + i;
//                int temp_counter = 0;
//                bool is_up = false;
//                while (temp_counter < 6 && j_up < polar_radius_cell)
//                {
//                    index_up = j_up * polar_angle_cell + i;
//                    if (polar_ogm_[index_up].type == UNIDENTIFY)
//                    {
//                        is_up = true;
//                        break;
//                    }
//                    temp_counter++;
//                    j_up++;
//                }
//                if (polar_ogm_[polar_index].type == UNIDENTIFY)
//                {
//                    ground_z = ground_z + polar_ogm_[index_pre].grad_m*(j-j_pre)*polar_radius_resolution_;
//                    float delta_ground_z = polar_ogm_[polar_index].min_z - ground_z;
//                    if (is_find_groundradius[i] > 0)
//                    {
//                        is_find_groundradius[i] = j;
//                        ground_z = polar_ogm_[polar_index].min_z;
//                        if (polar_ogm_[polar_index].delta_z < 0.35 && fabs(delta_ground_z)<0.35)
//                            ground_z = polar_ogm_[polar_index].average_z;
//
//                    } else
//                    {
//                        is_find_groundradius[i] = j;
//                        ground_z = polar_ogm_[polar_index].min_z;
//                        if(is_find_groundradius[i]>0)
//                        {
//                            polar_ogm_[polar_index].grad_b = j*polar_radius_resolution_;
//                            polar_ogm_[polar_index].grad_m = ground_z;
//                            for (int k = 1; k < is_find_groundradius[i]; ++k)
//                            {
//                                int temp_index1 = k*polar_angle_cell + i;
//                                polar_ogm_[polar_index].ground_z = ground_z*k/j;
//                                polar_ogm_[temp_index1].grad_b =  polar_ogm_[polar_index].grad_b;
//                                polar_ogm_[temp_index1].grad_m = ground_z*k/j;
//                            }
//                        }
//                    }
//
//                    polar_ogm_[polar_index].grad_b = (j - j_pre)*polar_radius_resolution_;
//                    polar_ogm_[polar_index].grad_m = (ground_z - polar_ogm_[index_pre].ground_z)/polar_ogm_[polar_index].grad_b;
//                    polar_ogm_[polar_index].ground_z = ground_z;
//                    is_find_groundradius[i] = j;
//                    j_pre = j;
//
//                    if(polar_ogm_[polar_index].delta_z < 0.35)
//                    {
//                        polar_ogm_[polar_index].type = GROUND;
//                    } else
//                    {
//                        polar_ogm_[polar_index].type = RIGIDNOPASSABLE;
//                        if (is_up)
//                            polar_ogm_[polar_index].type = PASSABLE;
//                    }
//
//                    if (!is_up)
//                    {
//                        break;
//                    }
//                    if (is_up)
//                    {
//                        float groun_z_up = ground_z + polar_ogm_[polar_index].grad_m*(j_up-j)*polar_angle_resolution_;
//                        float delta_ground_z_up = polar_ogm_[index_up].min_z - groun_z_up;
//                        float delta_z_up = polar_ogm_[index_up].min_z - polar_ogm_[polar_index].max_z;
//                        float delta_z_sum = delta_ground_z_up + delta_z_up;
//                        if (polar_ogm_[polar_index].delta_z > 0.5 && fabs(delta_ground_z_up) > 0.5)
//                        {
//                            break;
//                        }
//                    }
//                }
//                j = j_up;
//            }
//        }
    }


    if (0)//0-10
    {
        int i_start = (int)(270/polar_angle_resolution_);
        for (int ii = 0; ii < polar_angle_cell; ++ii)
        {
            int i = value_in_threshod_int(i_start+ii, 0, polar_angle_cell-1);
            float ground_z = 0;
            int j_pre = 0;
            int index_pre = j_pre * polar_angle_cell + i;
            bool is_break = false;
            for (int j = 2; j < 10 / polar_radius_resolution_;)
            {
                int polar_index = j * polar_angle_cell + i;
                index_pre = j_pre * polar_angle_cell + i;
                int j_up = j + 1;
                int index_up = j_up * polar_angle_cell + i;
                int temp_counter = 0;
                bool is_up = false;
                while (temp_counter < 6 && j_up < polar_radius_cell)
                {
                    index_up = j_up * polar_angle_cell + i;
                    if (polar_ogm_[index_up].type == UNIDENTIFY)
                    {
                        is_up = true;
                        break;
                    }
                    temp_counter++;
                    j_up++;
                }
                if (polar_ogm_[polar_index].type == UNIDENTIFY)
                {
                    ground_z = ground_z + polar_ogm_[index_pre].grad_m*(j-j_pre)*polar_radius_resolution_;
                    float delta_ground_z = polar_ogm_[polar_index].min_z - ground_z;
                    if (is_find_groundradius[i] > 0)
                    {
                        is_find_groundradius[i] = j;
                        ground_z = polar_ogm_[polar_index].min_z;
                        if (polar_ogm_[polar_index].delta_z < 0.35 && fabs(delta_ground_z)<0.35)
                            ground_z = polar_ogm_[polar_index].average_z;

                    } else
                    {
                        is_find_groundradius[i] = j;
                        ground_z = polar_ogm_[polar_index].min_z;
                        if(is_find_groundradius[i]>0)
                        {
                            polar_ogm_[polar_index].grad_b = j*polar_radius_resolution_;
                            polar_ogm_[polar_index].grad_m = ground_z;
                            for (int k = 1; k < is_find_groundradius[i]; ++k)
                            {
                                int temp_index1 = k*polar_angle_cell + i;
                                polar_ogm_[polar_index].ground_z = ground_z*k/j;
                                polar_ogm_[temp_index1].grad_b =  polar_ogm_[polar_index].grad_b;
                                polar_ogm_[temp_index1].grad_m = ground_z*k/j;
                            }
                        }
                    }

                    polar_ogm_[polar_index].grad_b = (j - j_pre)*polar_radius_resolution_;
                    polar_ogm_[polar_index].grad_m = (ground_z - polar_ogm_[index_pre].ground_z)/polar_ogm_[polar_index].grad_b;
                    polar_ogm_[polar_index].ground_z = ground_z;
                    is_find_groundradius[i] = j;
                    j_pre = j;

                    if(polar_ogm_[polar_index].delta_z < 0.35)
                    {
                        polar_ogm_[polar_index].type = GROUND;
                    } else
                    {
                        polar_ogm_[polar_index].type = RIGIDNOPASSABLE;
                        if (is_up)
                            polar_ogm_[polar_index].type = PASSABLE;
                    }

                    if (!is_up)
                    {
                        break;
                    }
                    if (is_up)
                    {
                        float groun_z_up = ground_z + polar_ogm_[polar_index].grad_m*(j_up-j)*polar_angle_resolution_;
                        float delta_ground_z_up = polar_ogm_[index_up].min_z - groun_z_up;
                        float delta_z_up = polar_ogm_[index_up].min_z - polar_ogm_[polar_index].max_z;
                        float delta_z_sum = delta_ground_z_up + delta_z_up;
                        if (polar_ogm_[polar_index].delta_z > 0.5 && fabs(delta_ground_z_up) > 0.5)
                        {
                            break;
                        }
                    }
                }
                j = j_up;
            }
        }
        for (int ii = 0; ii < polar_angle_cell; ++ii)
        {
            int i = value_in_threshod_int(i_start+ii, 0, polar_angle_cell-1);
            int j_pre = is_find_groundradius[i];
            int j_start = is_find_groundradius[i];
            for (int j = j_start+1; j < 10 / polar_radius_resolution_;)
            {
                int polar_index = j * polar_angle_cell + i;
                int index_pre = j_pre * polar_angle_cell + i;

                int j_up = j + 1;
                int index_up = j_up * polar_angle_cell + i;
                if (polar_ogm_[polar_index].type == UNIDENTIFY)
                {
                    polar_ogm_[polar_index].ground_z = polar_ogm_[index_pre].ground_z
                                                       + polar_ogm_[index_pre].grad_m*(j-j_pre)*polar_radius_resolution_;
                    float delta_ground_z = polar_ogm_[polar_index].min_z - polar_ogm_[polar_index].ground_z;
                    float delta_ground_z_max = polar_ogm_[polar_index].max_z - polar_ogm_[polar_index].ground_z;
                    if (fabs(delta_ground_z_max)>0.35)
                    {
                        polar_ogm_[polar_index].type = RIGIDNOPASSABLE;
                        if (fabs(delta_ground_z)<0.2)
                        {
                            polar_ogm_[polar_index].type = PASSABLE;
                            polar_ogm_[polar_index].ground_z = polar_ogm_[polar_index].min_z;
                            polar_ogm_[polar_index].grad_b = (j - j_pre);
                            polar_ogm_[polar_index].grad_m = (polar_ogm_[polar_index].ground_z
                                                              - polar_ogm_[index_pre].ground_z)/(j-j_pre);
                            is_find_groundradius[i] = j;
                            j_pre = j;
                        }
                    } else
                    {
                        polar_ogm_[polar_index].type = PASSABLE;
                        polar_ogm_[polar_index].ground_z = polar_ogm_[polar_index].min_z;
                        polar_ogm_[polar_index].grad_b = (j - j_pre);
                        polar_ogm_[polar_index].grad_m = (polar_ogm_[polar_index].ground_z
                                                          - polar_ogm_[index_pre].ground_z)/(j-j_pre);
                        is_find_groundradius[i] = j;
                        j_pre = j;
                    }
                }
                j = j_up;
            }
        }
    }

    if (0)//10-25
    {
        int i_start = (int)(270/polar_angle_resolution_);
        for (int ii = 0; ii < polar_angle_cell; ++ii)
        {
            int i = value_in_threshod_int(i_start+ii, 0, polar_angle_cell-1);
            int j_pre = is_find_groundradius[i];
            int j_start = is_find_groundradius[i];
            for (int j = j_start+1; j < 10 / polar_radius_resolution_;)
            {
                int polar_index = j * polar_angle_cell + i;
                int index_pre = j_pre * polar_angle_cell + i;

                int j_up = j + 1;
                int index_up = j_up * polar_angle_cell + i;
                int temp_counter = 0;
                bool is_up = false;
                while (temp_counter < 10 && j_up < polar_radius_cell)
                {
                    index_up = j_up * polar_angle_cell + i;
                    if (polar_ogm_[index_up].type == UNIDENTIFY)
                    {
                        is_up = true;
                        break;
                    }
                    temp_counter++;
                    j_up++;
                }
                if (polar_ogm_[polar_index].type == UNIDENTIFY)
                {
                    polar_ogm_[polar_index].ground_z = polar_ogm_[index_pre].ground_z
                                                       + polar_ogm_[index_pre].grad_m*(j-j_pre);
                    float delta_ground_z = polar_ogm_[polar_index].min_z - polar_ogm_[polar_index].ground_z;
                    float delta_ground_z_max = polar_ogm_[polar_index].max_z - polar_ogm_[polar_index].ground_z;
                    if (fabs(delta_ground_z_max)>0.35)
                    {
                        polar_ogm_[polar_index].type = RIGIDNOPASSABLE;
                        if (fabs(delta_ground_z)<0.2)
                        {
                            polar_ogm_[polar_index].type = PASSABLE;
                            polar_ogm_[polar_index].ground_z = polar_ogm_[polar_index].min_z;
                            polar_ogm_[polar_index].grad_b = (j - j_pre);
                            polar_ogm_[polar_index].grad_m = (polar_ogm_[polar_index].ground_z
                                                              - polar_ogm_[index_pre].ground_z)/(j-j_pre);
                            is_find_groundradius[i] = j;
                            j_pre = j;
                        }
                    } else
                    {
                        polar_ogm_[polar_index].type = PASSABLE;
                        polar_ogm_[polar_index].ground_z = polar_ogm_[polar_index].min_z;
                        if (polar_ogm_[polar_index].delta_z < 0.35)
                        {
                            polar_ogm_[polar_index].ground_z = polar_ogm_[polar_index].average_z;
                            polar_ogm_[polar_index].type = GROUND;
                        }
                        polar_ogm_[polar_index].grad_b = (j - j_pre);
                        polar_ogm_[polar_index].grad_m = (polar_ogm_[polar_index].ground_z
                                                          - polar_ogm_[index_pre].ground_z)/(j-j_pre);
                        is_find_groundradius[i] = j;
                        j_pre = j;
                    }
                }
                j = j_up;
            }
        }
    }
    if (0)//25-
    {
        int i_start = (int)(270/polar_angle_resolution_);
        for (int ii = 0; ii < polar_angle_cell; ++ii)
        {
            int i = value_in_threshod_int(i_start+ii, 0, polar_angle_cell-1);
            int j_pre = is_find_groundradius[i];
            int j_start = is_find_groundradius[i];
            for (int j = j_start+1; j < 10 / polar_radius_resolution_;)
            {
                int polar_index = j * polar_angle_cell + i;
                int index_pre = j_pre * polar_angle_cell + i;

                int j_up = j + 1;
                int index_up = j_up * polar_angle_cell + i;
                int temp_counter = 0;
                bool is_up = false;
                while (temp_counter < 6 && j_up < polar_radius_cell)
                {
                    index_up = j_up * polar_angle_cell + i;
                    if (polar_ogm_[index_up].type == UNIDENTIFY)
                    {
                        is_up = true;
                        break;
                    }
                    temp_counter++;
                    j_up++;
                }
                if (polar_ogm_[polar_index].type == UNIDENTIFY)
                {
                    polar_ogm_[polar_index].ground_z = polar_ogm_[index_pre].ground_z
                                                       + polar_ogm_[index_pre].grad_m*(j-j_pre);
                    float delta_ground_z = polar_ogm_[polar_index].min_z - polar_ogm_[polar_index].ground_z;
                    float delta_ground_z_max = polar_ogm_[polar_index].max_z - polar_ogm_[polar_index].ground_z;
                    if (fabs(delta_ground_z_max)>0.35)
                    {
                        polar_ogm_[polar_index].type = RIGIDNOPASSABLE;
                        if (fabs(delta_ground_z)<0.2)
                        {
                            polar_ogm_[polar_index].type = PASSABLE;
                            polar_ogm_[polar_index].ground_z = polar_ogm_[polar_index].min_z;
                            polar_ogm_[polar_index].grad_b = (j - j_pre);
                            polar_ogm_[polar_index].grad_m = (polar_ogm_[polar_index].ground_z
                                                              - polar_ogm_[index_pre].ground_z)/(j-j_pre);
                            is_find_groundradius[i] = j;
                            j_pre = j;
                        }
                    } else
                    {
                        polar_ogm_[polar_index].type = PASSABLE;
                        polar_ogm_[polar_index].ground_z = polar_ogm_[polar_index].min_z;
                        polar_ogm_[polar_index].grad_b = (j - j_pre);
                        polar_ogm_[polar_index].grad_m = (polar_ogm_[polar_index].ground_z
                                                          - polar_ogm_[index_pre].ground_z)/(j-j_pre);
                        is_find_groundradius[i] = j;
                        j_pre = j;
                    }
                }
                j = j_up;
            }
        }
    }

    delete[] groundradius_index_first;
    delete[] is_find_groundradius;

}
void OGMMappingUtils::PolarOGM_Ground(Polar_Cell* polar_ogm_, Line_s* polar_fit_line_,float polarogm_angle_, float polarogm_radius_,
                              float polarogm_angle_resolution_, float polarogm_radius_resolution_,
                              Polar_Cell* largepolar_ogm_, float largepolarogm_angle_, float largepolarogm_radius_,
                              float largepolarogm_angle_resolution_, float largepolarogm_radius_resolution_)
{
    int polar_angle_cell = boost::math::round(polarogm_angle_ / polarogm_angle_resolution_ );
    int polar_radius_cell = boost::math::round(polarogm_radius_ / polarogm_radius_resolution_);
    int polar_cell_size_ = polar_radius_cell* polar_angle_cell;

    int largepolar_angle_cell = boost::math::round(largepolarogm_angle_ / largepolarogm_angle_resolution_ );
    int largepolar_radius_cell = boost::math::round(largepolarogm_radius_ / largepolarogm_radius_resolution_);
    int largepolar_cell_size_ = largepolar_radius_cell* largepolar_angle_cell;



}

void OGMMappingUtils::GridOGM_Ground(Polar_Cell* polar_ogm_, float polarogm_angle_, float polarogm_radius_,float polarogm_angle_resolution_, float polarogm_radius_resolution_,
                    OGM_Cell* rigid_ogm_, float ogm_width_, float ogm_height_ , float ogm_resolution_, float offest_y_ )
{
    int rigidogmwidth_cell = boost::math::round(ogm_width_ / ogm_resolution_) + 1;//501
    int rigidogmheight_cell = boost::math::round(ogm_height_ / ogm_resolution_) + 1;//501
    int polarogm_radius_cell = boost::math::round( polarogm_radius_/ polarogm_radius_resolution_ );
    int polarogm_angle_cell = boost::math::round( polarogm_angle_/ polarogm_angle_resolution_ );
    int polarogm_cell_size = polarogm_angle_cell * polarogm_radius_cell;

    for (int j=0; j<polarogm_angle_cell; j++)
    {
        for (int i = 25/polarogm_radius_resolution_; i < polarogm_radius_cell; i++)
        {
            int polar_index = i*polarogm_angle_cell + j;
            if( polar_ogm_[polar_index].type > UNKNOWN )
            {
                float deltaheight = (polar_ogm_[polar_index].max_z - polar_ogm_[polar_index].ground_z);
                if(i < 20/polarogm_radius_resolution_)
                {
                    if (deltaheight>0.5 && polar_ogm_[polar_index].delta_z > 0.35)
                    {
                        polar_ogm_[polar_index].type = RIGIDNOPASSABLE;
                    }
                    else
                    {
                        polar_ogm_[polar_index].type = GROUND;
                    }
                } else
                {
                    if (deltaheight>0.7 || polar_ogm_[i].delta_z > 0.35)
                    {
                        polar_ogm_[polar_index].type = RIGIDNOPASSABLE;
                    }
                    else
                    {
                        polar_ogm_[polar_index].type = GROUND;
                    }
                }
            }
        }
    }

    for (int j = 0; j < rigidogmheight_cell; j++)
    {
        for (int i = 0;  i < rigidogmwidth_cell; ++ i)
        {
            int rigid_index = j*rigidogmwidth_cell + i;
            if (rigid_ogm_[rigid_index].type > UNKNOWN)
            {
                float x = (i)*ogm_resolution_ -ogm_width_/2;
                float y = j*ogm_resolution_ - offest_y_;
                float azimuth = BaseFunction::Angle_atan2( x, y);
                float dis_xy = sqrt(x*x + y*y);

                if(rigid_ogm_[rigid_index].delta_z >= 0.40 )
                {
                    rigid_ogm_[rigid_index].type = RIGIDNOPASSABLE;
                }
                else
                {
                    rigid_ogm_[rigid_index].type = GROUND;
                }

                if(dis_xy <0)
                {
                    int angle_col = (int)(azimuth / polarogm_angle_resolution_);
                    int radius_row = (int)(dis_xy / polarogm_radius_resolution_);
                    int polar_index = radius_row*polarogm_angle_cell + angle_col;
                    if (polar_index<polarogm_cell_size)
                    {
                        rigid_ogm_[rigid_index].ground_z = polar_ogm_[polar_index].ground_z;
                        rigid_ogm_[rigid_index].max_z = rigid_ogm_[rigid_index].max_z - polar_ogm_[polar_index].ground_z;
                        if(polar_ogm_[polar_index].type>UNIDENTIFY)
                        {
                            float delta_max_z = rigid_ogm_[rigid_index].max_z - polar_ogm_[polar_index].ground_z;
                            if(polar_ogm_[polar_index].type == GROUND)
                            {
                                rigid_ogm_[rigid_index].type = GROUND;
                            } else
                            {
                                if (delta_max_z > 0.5)
                                {
                                    rigid_ogm_[rigid_index].type = RIGIDNOPASSABLE;
                                } else
                                {
                                    rigid_ogm_[rigid_index].type = GROUND;
                                }
                            }
                        }
                    }
                }

            }
        }
    }
}
