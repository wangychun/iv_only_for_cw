
#pragma once
#include "../StructMovingTargetDefine.h"
#include "../ShowResult.h"
#include <opencv2/opencv.hpp>
#include <vector>
#include <iostream>

using namespace std;

class TargetDetecter
{
public:
	TargetDetecter();
	~TargetDetecter();


	//初始化类的一些成员变量
	void MapInput(int frame_counter_, float ogm_width_, float ogm_height_, float ogm_offest_y_, float ogm_resolution_,
		 float polarogm_angle_, float polarogm_radius_, float polarogm_angle_resolution_, float polarogm_radius_resolution_,
				 int virtual_line_num_, int virtual_line_resolution_);
	//目标检测,对二值图像img_ogm_进行
	void Detect(IplImage *img_ogm_, OGM_Cell *rigid_ogm_, int rigidogm_size_, Polar_Cell* polar_ogm_, int polarogm_size_,
		vector<CandidateObject> *fusion_target_measure_, Line_int* boundary_line_);
	/*!
	 * @brief 将图像坐标系下点转为车体坐标系(x轴向右,y轴向前)下米制单位点坐标
	 * @param temp_object_
	 */
	void Transf_Candidate( const std::vector<CandidateObject>& object_image,std::vector<CandidateObject>& object_vehicle);

private:
    void PreProcessing(IplImage *img_ogm_);
    void Virtual_line();
    void TargetClustering(IplImage *img_contours_);
    void TargetIdentify( OGM_Cell *rigid_ogm_, Polar_Cell* polar_ogm_);//
    void Target_Array();

	void Release();

	void  InitLine(Line_s* line_, float x1_, float y1_, float x2_, float y2_);
	CvPoint2D32f  Point_line2(Line_s line1_, Line_s line2_);

	void ShowEgoVehicle(IplImage* img, int map_offest_y_, float ogm_resolution_, float egocar_with_, float egocar_height_);
	void ShowObject(IplImage* img, CandidateObject object_show_ , int object_ID_, CvScalar object_color_, int thinkness_);
	void InitCandidate( CvRect object_rect_, CvBox2D object_box_,CandidateObject* temp_object);

	void Grid_Points(CandidateObject* temp_object, vector<CvPoint2D32f> *grid_point_vector_,
					 OGM_Cell* rigid_ogm_, Polar_Cell* polar_ogm_);
	void Grid_fit_line(CandidateObject* temp_object,vector<CvPoint2D32f> grid_point_vector_,
					   float* line_angle_, CvPoint2D32f* base_point_);
    void CorrectShape(CandidateObject* temp_object, vector<CvPoint2D32f> grid_point_vector_,
					   float line_angle_, CvPoint2D32f base_point_);
	void OcclusionState(CandidateObject* temp_object, Polar_Cell* polar_ogm_);
    void Trackpoint_index(CandidateObject* temp_object, int step_);

    void TransformPolarPoint(CandidateObject* temp_object);
    /*!
     * @brief 目标类型判别
     * @param object_with_  宽度(米制单位）
     * @param object_length_ 长度(米制单位）
     * @return 1-9等级
     */
    int  ObjectType_Classify(const float& object_with_, const float& object_length_);
    void Identify_PoseHead( CandidateObject* temp_object);

    void Virtual_line_draw(Line_int* virtual_line_, int line_num_, float resolution_, IplImage* img_, int method_);
    /*!
     * @brief 按相邻射线长度聚类射线
     * @param virtual_line_[in]
     * @param line_num_
     * @param line_cluster_vector_[out] 射线标号
     */
    void Virtual_line_cluster(Line_int* virtual_line_, int line_num_, vector<Cluster_Index>* line_cluster_vector_);
	void Shape_L_I_detect(vector<Cluster_Index>* line_cluster_vector_);

public:
    int frame_counter;
    bool is_show_img;
    State_Vehicle ego_veh_state_current;
protected:
	IplConvKernel* close_element;
	IplConvKernel* dilate_element;
	IplConvKernel* vertial_close_element;
	CvMemStorage*  storage;

	IplImage* img_result;
	IplImage* img_ogm;
	IplImage* img_close;
	IplImage* img_temp;
	IplImage* img_virtual_line;

	int virtual_line_num;
	float virtual_line_resolution;
	Line_float* virtual_line_float;
	Line_int* virtual_line;
	Line_int* virtual_line_d;
	int* virtual_line_type;
	
	//map
	int map_width;
	int map_height;
	int map_offset_y;
	float map_resolution;
	CvPoint ego_veh_position;


	// refine ogm
	int rigidogm_cell_size;
	OGM_Cell* rigid_ogm;
	
	//polar_ogm
	float polarogm_radius_resolution;
	float polarogm_angle_resolution;
	float polarogm_radius; //2.5m-6m
	float polarogm_angle;

	int polarogm_radius_cell;
	int polarogm_angle_cell;
	int polarogm_cell_size;
	Polar_Cell* polar_ogm;

	//
	float region_radius;
	float region_angle;
	float regionradius_resolution;
	float regionangle_resolution;
	int regionradius_cell;
	int regionangle_cell;
	Cluster_Index* region_candidate;

	//
    vector<Cluster_Index> line_cluster_vector;
	vector<CandidateObject> total_object_vector;
	vector<CandidateObject> line_object_vector;

	int target_num;//检测到多少个目标

	ShowResult show_result;

private:
};
