
#pragma once
#include <cv.h>
#include <highgui.h>
#include <cxcore.h>
#include <vector>

#include "../StructMovingTargetDefine.h"
#include "../ShowResult.h"
using namespace std;


class Filter_Upadate
{
public:
	Filter_Upadate();
	~Filter_Upadate();

	ShowResult show_result;

public:

};
