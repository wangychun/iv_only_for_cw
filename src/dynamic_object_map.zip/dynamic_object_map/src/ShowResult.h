#pragma once

#include <opencv2/opencv.hpp>
#include <vector>
#include <iostream>
#include "StructMovingTargetDefine.h"

class ShowResult
{
public:
    ShowResult();
	~ShowResult();
	//1.
	void ShowTrackingResult(IplImage *img_result, float ogm_resolution_, float ogm_offest_y_,
		vector<MovingObject> *moving_object_vector_tracking_);//

    int value_in_threshod_int(int value_, int threshod_pre_, int threshod_up_);
    void point_local_to_global(float x_, float y_, State_Vehicle ego_state_, double* lng_x_, double* lat_y_);
    void point_global_to_local(double lng_x_, double lat_y_ ,State_Vehicle ego_state_, float* x_, float* y_);

	//math function
	void HistoricalTrajectoryOptimization(MovingObject temp_object,IplImage* img);

	CvPoint3D32f pointAdd(CvPoint3D32f p, CvPoint3D32f q);//
	CvPoint3D32f pointTimes(float c, CvPoint3D32f p);// =c*p
	CvPoint3D32f Bernstein(float u, CvPoint3D32f *p);// ,P1*t^3 + P2*3*t^2*(1-t) + P3*3*t*(1-t)^2 + P4*(1-t)^3 = Pnew
	float DisPoint2Line(CvPoint2D32f* point,Line* line);
	float DisPoint2Point(CvPoint2D32f point_1,CvPoint2D32f point_2);
	//float CalSumLength(CvPoint2D32f* points,int num);

	//2.show moving object

	void DrawRect(IplImage* img,CvRect* rect,CvScalar color,int thickness);
	void DrawArrow(IplImage* img, CvPoint point_start_, CvPoint point_end_, CvScalar color_, int thickness);

	void ShowKalmanRange(MovingObject temp_object,IplImage* img,CvScalar color_kalman);
	void ShowHistoryPoints(MovingObject temp_object,IplImage* img,CvScalar color_history_points);
	void ShowID(MovingObject temp_object,IplImage* img,CvScalar color_ID);
	void ShowVelocity(MovingObject temp_object,IplImage* img,CvScalar color_velocity);
	void ShowModelPosition(MovingObject temp_object,IplImage* img,CvScalar color_rect,CvScalar color_box);
	

    void ShowEgoVehicle(IplImage* img_, int map_offest_y_, float ogm_resolution_, float egocar_with_, float egocar_height_);
    void ShowPolarOGM(IplImage* img_, Polar_Cell* polar_ogm_, float polarogm_angle_, float polarogm_radius_,
                      float polarogm_angle_resolution_, float polarogm_radius_resolution_);
    void ShowObject_candidate(IplImage* img_, CandidateObject temp_object , int object_ID_, CvScalar object_color_, int thinkness_);
    void ShowObject_moving(IplImage* img_, MovingObject temp_object , int object_ID_);
    void ShowObject_radar(IplImage* img_, Radar_Target temp_object , int object_ID_, CvScalar object_color_, int thinkness_);
    void Show_word(IplImage* img_, int target_num_, float cost_time_);

	void ShowObjectCubic( boost::shared_ptr<PCLVisualizer> cloud_viewer_, Object_Shape shape_,
						  int ID_,double red_, double green_, double blue_ );
	void Show_word3D( boost::shared_ptr<PCLVisualizer> cloud_viewer_, MovingObject temp_object, int ID_,
					  double red_, double green_, double blue_ );
	void Show_traj3D( boost::shared_ptr<PCLVisualizer> cloud_viewer_, MovingObject temp_object, int ID_,
	double red_, double green_, double blue_ );
	//显示运动目标轨迹
	void Show_moving_vector(IplImage* img_, vector<MovingObject> moving_object_vector_);
	void Show_candidate_vector(IplImage* img_, vector<CandidateObject> candidate_object_vector_);
	void Show_radar_vector(IplImage* img_, vector<Radar_Target> radar_target_vector_);

	int map_width;
	int map_height;
	int map_offset_y;
	float map_resolution;
	CvPoint ego_veh_position;//本车在图像中位置,像素坐标
	State_Vehicle ego_veh_state_current;
    int frame_counter;

	double ego_veh_dlng;
	double ego_veh_dlat;
	double ego_veh_dheading;
	float ego_veh_fForwardVel;
	double ego_veh_fFLRWheelAverAngle;
};
