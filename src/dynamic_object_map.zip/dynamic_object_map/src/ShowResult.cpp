#include "ShowResult.h"
using namespace std;
ShowResult::ShowResult()
{
}
ShowResult::~ShowResult()
{
}

/************************************************************************/
CvPoint3D32f ShowResult::pointAdd(CvPoint3D32f p, CvPoint3D32f q) 
{
	p.x += q.x; 
	p.y += q.y; 
	p.z += q.z;
	return p;
}

CvPoint3D32f ShowResult::pointTimes(float c, CvPoint3D32f p) 
{
	p.x *= c; p.y *= c; p.z *= c;
	return p;
}

CvPoint3D32f ShowResult::Bernstein(float u, CvPoint3D32f *p) 
{
	//P1*t^3 + P2*3*t^2*(1-t) + P3*3*t*(1-t)^2 + P4*(1-t)^3 = Pnew 
	CvPoint3D32f a, b, c, d, r;

	a = pointTimes(pow(u,3), p[0]);
	b = pointTimes(3*pow(u,2)*(1-u), p[1]);
	c = pointTimes(3*u*pow((1-u),2), p[2]);
	d = pointTimes(pow((1-u),3), p[3]);

	r = pointAdd(pointAdd(a, b), pointAdd(c, d));

	return r;
}

void ShowResult::HistoricalTrajectoryOptimization(MovingObject temp_object,IplImage* img)
{
}

//************************** show object   *****************************//

void ShowResult::DrawRect(IplImage* img,CvRect* rect,CvScalar color,int thickness)
{
	CvPoint point1 = cvPoint(rect->x,rect->y);
	CvPoint point2 = cvPoint(rect->x + rect->width,rect->y + rect->height);
	cvRectangle(img,point1,point2,color,thickness,8,0);
}
void ShowResult::DrawArrow(IplImage* img, CvPoint point_start_, CvPoint point_end_, CvScalar color_, int thickness)
{
	float angle_arrow = atan2((double)(point_end_.y-point_start_.y), (double)(point_end_.x - point_start_.x));
	angle_arrow = angle_arrow*pi/180;
	CvPoint2D32f point_arrow0;
	CvPoint2D32f point_arrow1;
	CvPoint2D32f point_arrow2;
	point_arrow0.x = point_end_.x + 5*cos(angle_arrow);
	point_arrow0.y = point_end_.x + 5*sin(angle_arrow);
	point_arrow1.x = point_end_.x + 3*cos(angle_arrow + pi/2);
	point_arrow1.y = point_end_.x + 3*sin(angle_arrow + pi/2);
	point_arrow2.x = point_end_.x + 3*cos(angle_arrow - pi/2);
	point_arrow2.y = point_end_.x + 3*sin(angle_arrow - pi/2);
	
	CvPoint pt[3];
	pt[0] = cvPointFrom32f(point_arrow0);
	pt[1] = cvPointFrom32f(point_arrow1);
	pt[2] = cvPointFrom32f(point_arrow2);

	cvFillConvexPoly(img,pt,3,cvScalar(0,255,0),8,0);
}

//************************** show object   *****************************//
void ShowResult::ShowHistoryPoints(MovingObject temp_object,IplImage* img,CvScalar color_history_points)
{
}
void ShowResult::ShowKalmanRange(MovingObject temp_object, IplImage* img, CvScalar color_kalman)
{
}
void ShowResult::ShowID(MovingObject temp_object, IplImage* img, CvScalar color_ID)
{
    CvPoint temp_point_pre = cvPoint((int)(temp_object.object_rect.x+temp_object.object_rect.width/2),temp_object.object_rect.y);
	/*temp_point_pre.x = (int)( (temp_object.object_rect.x + temp_object.object_rect.width/2)/ map_resolution + map_width/2 );
	temp_point_pre.y = (int)( map_height - (temp_object.object_rect.y/ map_resolution + map_offset_y) );*/

	char file_name[50];
	CvFont font;
	cvInitFont(&font, CV_FONT_HERSHEY_PLAIN, 0.8f, 1.0f, 0, 1, 8);
	sprintf(file_name, "%d %.1f %.1f", temp_object.ID_number, temp_object.motion_state.v_x_post*5, 
		temp_object.motion_state.v_y_post*5 + ego_veh_state_current.fForwardVel);

	cvPutText(img, file_name, temp_point_pre, &font, cvScalar(0,197,255));

}

void ShowResult::ShowVelocity(MovingObject temp_object,IplImage* img, CvScalar color_velocity)
{	
	CvPoint2D32f temp_point_now_32;
	temp_point_now_32.x = temp_object.center_point.x/ map_resolution + img->width/2;
	temp_point_now_32.y = img->height - temp_object.center_point.y/ map_resolution - map_offset_y;
	CvPoint temp_point_now = cvPointFrom32f(temp_point_now_32);
	
	CvPoint2D32f point_v_32;
	point_v_32.x = temp_point_now_32.x + temp_object.motion_state.v_x_post  /map_resolution/2;
	point_v_32.y = temp_point_now_32.y - (temp_object.motion_state.v_y_post + ego_veh_state_current.fForwardVel) /map_resolution/2;
	CvPoint point_v = cvPointFrom32f(point_v_32);

	//cvCircle(img, temp_point_now, 3, color_velocity, 2, 8, 0);
	cvLine(img, temp_point_now, point_v, color_velocity, 2, 8, 0);	

	if (1)
		DrawArrow(img, temp_point_now, point_v, color_velocity, 1);
}


void ShowResult::ShowModelPosition(MovingObject temp_object, IplImage* img, CvScalar color_rect, CvScalar color_box)
{
	if (0)
	{
		CvRect rect_roi = cvRect(temp_object.object_rect.x, temp_object.object_rect.y,
			temp_object.object_rect.width, temp_object.object_rect.height);
		cvSetImageROI(img, rect_roi);
		for (int i=temp_object.object_rect.y; i<(temp_object.object_rect.y + temp_object.object_rect.height); i++)
		{
			for (int j=temp_object.object_rect.x; j<(temp_object.object_rect.x + temp_object.object_rect.width); j++)
			{
				uchar* val = ((uchar *)(img->imageData + i*img->widthStep));			
				if (val[j*img->nChannels + 0]>10 && val[j*img->nChannels + 1]>10 && val[j*img->nChannels + 2]>10)
				{
					((uchar *)(img->imageData + i*img->widthStep))[j*img->nChannels + 0]=0; // B
					((uchar *)(img->imageData + i*img->widthStep))[j*img->nChannels + 1]=165; // G
					((uchar *)(img->imageData + i*img->widthStep))[j*img->nChannels + 2]=255; // R
				}
			}
		}
		cvResetImageROI(img);
	}
	

	CvBox2D object_box = temp_object.object_box;
	CvPoint2D32f object_box_point4[4];
	cvBoxPoints(object_box, object_box_point4);//�õ�track_box�ĸ��ǵĵ������

    int show_rect_box = 2;// 1 rect; 2 box
	switch (show_rect_box)//(temp_object.compare_result)//��ֱ�������¿���ֻ��һ��ģ�;Ϳ�����
	{
	case 1:
		{
			CvPoint point1 = cvPoint(temp_object.object_rect.x, temp_object.object_rect.y);
			CvPoint point2 = cvPoint(temp_object.object_rect.x + temp_object.object_rect.width,
				temp_object.object_rect.y + temp_object.object_rect.height);
			cvRectangle(img, point1, point2, color_rect ,1, 8, 0);

		}break;
	case 2:
		{
			if (1)
			{
				CvBox2D object_box = temp_object.object_box;
				CvPoint2D32f object_box_point4[4];
				cvBoxPoints(object_box, object_box_point4);//�õ�track_box�ĸ��ǵĵ������	
				CvPoint box_line_point4[4];
				for(int i=0; i<4; i++)
				{
					box_line_point4[i] = cvPointFrom32f(object_box_point4[i]);//��CvPoint2D32f���͵ĵ�תΪCvPoint����
				}	
				CvPoint* ppt_test = box_line_point4;
				int count=4;
				CvScalar temp_color_box = color_box;
				if (temp_object.shape.is_entire_head)
				{
					temp_color_box = cvScalar(255,255,0);
				}
				cvPolyLine(img, &ppt_test, &count, 1, 1, temp_color_box, 1);//������
			}
			
		}break;
	default: break;
	}
	
	if (temp_object.shape.head_index > -1)
	{
		int point_index_head = temp_object.shape.head_index;
		int point_index_pre = point_index_head - 1;
		int point_index_up = point_index_head + 1;
		int point_index_diag = point_index_diag + 2;
		if (point_index_pre < 0)
		{
			point_index_pre  = point_index_pre + 4;
		}
		if (point_index_up > 3 )
		{
			point_index_pre  = point_index_pre - 4;
		}
		if (point_index_diag > 3 )
		{
			point_index_pre  = point_index_pre - 4;
		}
		CvPoint2D32f point_head_32f, point_pre_32f, point_up_32f;
		point_head_32f.x = (temp_object.shape.point4[point_index_head].x + temp_object.shape.point4[point_index_up].x)/2;
		point_head_32f.y = (temp_object.shape.point4[point_index_head].y + temp_object.shape.point4[point_index_up].y)/2; ;
		point_pre_32f.x = temp_object.shape.point4[point_index_head].x/2 + temp_object.shape.point4[point_index_pre].x/2;
		point_pre_32f.y = temp_object.shape.point4[point_index_head].y/2 + temp_object.shape.point4[point_index_pre].y/2;
		point_pre_32f.x = temp_object.shape.point4[point_index_up].x/2 + temp_object.shape.point4[point_index_diag].x/2;
		point_up_32f.y = temp_object.shape.point4[point_index_up].y/2 + temp_object.shape.point4[point_index_diag].y/2;
		CvPoint point_head = cvPointFrom32f(point_head_32f);
		CvPoint point_pre = cvPointFrom32f(point_pre_32f);
		CvPoint point_up = cvPointFrom32f(point_pre_32f);
		cvLine(img, point_head, point_pre, cvScalar(255,255,0), 1, 8, 0);
		cvLine(img, point_head, point_up, cvScalar(255,255,0), 1, 8, 0);
		cvLine(img, point_pre, point_up, cvScalar(255,255,0), 1, 8, 0);

	}	
}

void ShowResult::ShowTrackingResult(IplImage *img_result, float ogm_resolution_, float ogm_offest_y_,
                                    vector<MovingObject> *moving_object_vector_tracking_)
{
	map_width = img_result->width;
	map_height = img_result->height;
	map_resolution = ogm_resolution_;
	map_offset_y = ogm_offest_y_/ map_resolution;
	ego_veh_position.x = img_result->width/2;
	ego_veh_position.y = img_result->height - map_offset_y;
}

void ShowResult::ShowEgoVehicle(IplImage* img_, int map_offest_y_, float ogm_resolution_, float egocar_with_, float egocar_height_)
{
	//1.���������
	CvPoint ego_vehicle = cvPoint( img_->width/2, (int)(img_->height - map_offest_y_) );
	int vehicle_width = egocar_with_/ ogm_resolution_;
	int vehicle_height = egocar_height_/ ogm_resolution_;
	CvPoint ego_vehicle_lt = cvPoint(ego_vehicle.x - vehicle_width/2, ego_vehicle.y - vehicle_height/2);
	CvPoint ego_vehicle_rb = cvPoint(ego_vehicle.x + vehicle_width/2, ego_vehicle.y + vehicle_height/2);
	cvRectangle(img_,ego_vehicle_lt,ego_vehicle_rb,cvScalar(0,0,0),-1,8,0);

	//2.��̥
	int tire_width = 1/ogm_resolution_;
	int tire_height = 2/ogm_resolution_;

	//������̥
	CvPoint ego_vehicle_ltb = cvPoint(ego_vehicle_lt.x + tire_width/2,ego_vehicle_lt.y + tire_height/2);
	cvRectangle(img_,ego_vehicle_lt,ego_vehicle_ltb,cvScalar(0,255,255),-1,8,0);
	//������̥
	CvPoint ego_vehicle_rtt = cvPoint(ego_vehicle.x + vehicle_width/2,ego_vehicle.y - vehicle_height/2);
	CvPoint ego_vehicle_rtb = cvPoint(ego_vehicle_rtt.x - tire_width/2,ego_vehicle_rtt.y + tire_height/2);
	cvRectangle(img_,ego_vehicle_rtt,ego_vehicle_rtb,cvScalar(0,255,255),-1,8,0);
	//������̥
	CvPoint ego_vehicle_rbt = cvPoint(ego_vehicle_rb.x - tire_width/2,ego_vehicle_rb.y - tire_height/2);
	cvRectangle(img_,ego_vehicle_rb,ego_vehicle_rbt,cvScalar(0,255,255),-1,8,0);
	//������̥
	CvPoint ego_vehicle_lbb = cvPoint(ego_vehicle.x - vehicle_width/2,ego_vehicle.y + vehicle_height/2);
	CvPoint ego_vehicle_lbt = cvPoint(ego_vehicle_lbb.x + tire_width/2,ego_vehicle_lbb.y - tire_height/2);
	cvRectangle(img_,ego_vehicle_lbb,ego_vehicle_lbt,cvScalar(0,255,255),-1,8,0);

	//3.����
	CvPoint pt[3];
	pt[0] = cvPoint(ego_vehicle.x,ego_vehicle.y - 1.2/ogm_resolution_);
	pt[1] = cvPoint(ego_vehicle.x - 0.6/ogm_resolution_, ego_vehicle.y + 0.8/ogm_resolution_);
	pt[2] = cvPoint(ego_vehicle.x + 0.6/ogm_resolution_, ego_vehicle.y + 0.8/ogm_resolution_);

	cvFillConvexPoly(img_,pt,3,cvScalar(0,255,0),8,0);

	int dis_10 = boost::math::round(10/ogm_resolution_);
	int dis10_width_num = 3;
	int dis10_height_num = 3;
	for (int i=0; i<(dis10_height_num); i++)
	{
		CvPoint line_point0;
		CvPoint line_point1;
		line_point0.x = 0;
		line_point0.y = ego_vehicle.y + i*20/ogm_resolution_;
		line_point1.x = img_->width;
		line_point1.y = ego_vehicle.y + i*20/ogm_resolution_;
		cvLine(img_, line_point0, line_point1, cvScalar(125,125,125), 1, 8, 0);
        if(1)
        {
            CvFont font;
            cvInitFont(&font, CV_FONT_HERSHEY_PLAIN, 0.8f, 1.0f, 0, 1, 8);
            char file_name_ID[50];
            sprintf(file_name_ID, "%dm ", -i*20);
            CvScalar word_color = cvScalar(125,125,125);
            CvPoint word_point;
            word_point.x = line_point0.x +2;
            word_point.y = line_point0.y;
            cvPutText(img_, file_name_ID, word_point, &font, word_color);
        }
		if (i>0)
		{
			line_point0.y = ego_vehicle.y - i*20/ogm_resolution_;
			line_point1.y = ego_vehicle.y - i*20/ogm_resolution_;
			cvLine(img_, line_point0, line_point1, cvScalar(125,125,125), 1, 8, 0);
            if(1)
            {
                CvFont font;
                cvInitFont(&font, CV_FONT_HERSHEY_PLAIN, 0.8f, 1.0f, 0, 1, 8);
                char file_name_ID[50];
                sprintf(file_name_ID, "%dm ", i*20);
                CvScalar word_color = cvScalar(125,125,125);
                CvPoint word_point;
                word_point.x = line_point0.x +5;
                word_point.y = line_point0.y;
                cvPutText(img_, file_name_ID, word_point, &font, word_color);
            }
		}
	}
	for (int i=0; i<(dis10_width_num); i++)
	{
		CvPoint line_point0;
		CvPoint line_point1;

		line_point0.x = ego_vehicle.x + i*20/ogm_resolution_ + 10/ogm_resolution_;
		line_point0.y = 0;
		line_point1.x = ego_vehicle.x + i*20/ogm_resolution_ + 10/ogm_resolution_;
		line_point1.y = img_->height;
		cvLine(img_, line_point0, line_point1, cvScalar(125,125,125), 1, 8, 0);

		line_point0.x = ego_vehicle.x - i*20/ogm_resolution_ - 10/ogm_resolution_;
		line_point1.x = ego_vehicle.x - i*20/ogm_resolution_ - 10/ogm_resolution_;
		cvLine(img_, line_point0, line_point1, cvScalar(125,125,125), 1, 8, 0);
		if (i==0)
		{
			line_point0.x = ego_vehicle.x;
			line_point0.y = ego_vehicle.y + 10/ogm_resolution_;
			line_point1.x = ego_vehicle.x;
			line_point1.y = ego_vehicle.y - 10/ogm_resolution_;
			cvLine(img_, line_point0, line_point1, cvScalar(155,155,155), 1, 8, 0);
		}
	}

}
void ShowResult::ShowPolarOGM(IplImage* img_, Polar_Cell* polar_ogm_, float polarogm_angle_, float polarogm_radius_,
							  float polarogm_angle_resolution_, float polarogm_radius_resolution_)
{
	int polarogm_angle_cell_ = boost::math::round(polarogm_angle_ / polarogm_angle_resolution_);
	int polarogm_radius_cell_ = boost::math::round((polarogm_radius_-10) / polarogm_radius_resolution_);;
	int polarogm_cell_size_ = polarogm_angle_cell_* polarogm_radius_cell_;
	for ( int j=0; j<polarogm_angle_cell_; j++)
	{
		float angle0 = j*polarogm_angle_resolution_;
		float angle1 = (j+1)*polarogm_angle_resolution_;
		float angle2 = (j+0.5)*polarogm_angle_resolution_;
		angle0 = 2*pi - angle0*pi/180;
		angle1 = 2*pi - angle1*pi/180;
		angle2 = 2*pi - angle2*pi/180;
		float dis_line = (polarogm_angle_cell_-0.5)*polarogm_radius_resolution_;
		for (int i=7; i<polarogm_radius_cell_; i++)
		{
			int polar_index = i*polarogm_angle_cell_ + j;
			float dis_xy0 = i*polarogm_radius_resolution_;
			float dis_xy1 = (i+1)*polarogm_radius_resolution_;
			float dis_xy2 = (i+0.5)*polarogm_radius_resolution_;
			CvPoint2D32f point_32[4];
			point_32[0].x = dis_xy0*cos(angle0)/map_resolution + img_->width/2;
			point_32[0].y = img_->height - dis_xy0*sin(angle0)/map_resolution - img_->height/2;
			point_32[1].x = dis_xy1*cos(angle0)/map_resolution + img_->width/2;
			point_32[1].y = img_->height - dis_xy1*sin(angle0)/map_resolution - img_->height/2;
			point_32[2].x = dis_xy1*cos(angle1)/map_resolution + img_->width/2;
			point_32[2].y = img_->height - dis_xy1*sin(angle1)/map_resolution - img_->height/2;
			point_32[3].x = dis_xy0*cos(angle1)/map_resolution + img_->width/2;
			point_32[3].y = img_->height - dis_xy0*sin(angle1)/map_resolution - img_->height/2;

			//CvPoint pt[4];
			//for (int m=0; m<4; m++)
			//{
			//	pt[m] = cvPointFrom32f(point_32[m]);
			//}
			if (polar_ogm_[polar_index].type > UNKNOWN)
			{
				//cvFillConvexPoly(img_,pt,4,cvScalar(0,255,0),8,0);
				if (polar_ogm_[polar_index].type == RIGIDNOPASSABLE)
				{
					//cvFillConvexPoly(img_,pt,4,cvScalar(0,255,0),8,0);
					//cvLine(img_, line_point[0], line_point[1], cvScalar(0,255,0), 1, 8, 0);
					dis_line = (i+0.5)*polarogm_radius_resolution_;
					break;
				}
			}
		}
		if (1)
		{
			CvPoint2D32f line_point_32[2];
			line_point_32[0].x = img_->width/2;
			line_point_32[0].y = img_->height/2;
			line_point_32[1].x = dis_line*cos(angle2)/map_resolution + img_->width/2;
			line_point_32[1].y = img_->height - dis_line*sin(angle2)/map_resolution - img_->height/2;
			CvPoint line_point[2];
			line_point[0] = cvPointFrom32f(line_point_32[0]);
			line_point[1] = cvPointFrom32f(line_point_32[1]);
			cvLine(img_, line_point[0], line_point[1], cvScalar(0,255,0), 1, 8, 0);
		}
	}
}

void ShowResult::ShowObject_radar(IplImage *img_, Radar_Target temp_object, int object_ID_, CvScalar object_color_, int thinkness_)
{
    int point_count = 4;
    CvPoint center_point;
    center_point.x = (int)(temp_object.x/map_resolution + img_->width/2);
    center_point.y = (int)(img_->height - temp_object.y/map_resolution - map_offset_y);

	CvScalar object_color = cvScalar(0,255,0);
	//if (temp_object.match_index<0)
		object_color = cvScalar(255,0,255);
    cvCircle(img_, center_point, 2, object_color, 2, 8, 0);

    CvPoint point_v;
    point_v.x = center_point.x + (int)temp_object.v_x*1.5;
    point_v.y = center_point.y + (int)temp_object.v_y*1.5;
    //cvLine(img_, center_point, point_v, cvScalar(0,0,255), 1,8,0);


    if(1)
    {
        CvFont font;
        cvInitFont(&font, CV_FONT_HERSHEY_PLAIN, 0.8f, 1.0f, 0, 1, 8);

        char file_name_ID[50];

        sprintf(file_name_ID, "%d %.1f ", temp_object.target_ID, temp_object.v);
        CvScalar word_color = cvScalar( 0, 255, 0 );
        CvPoint word_point = center_point;
        cvPutText(img_, file_name_ID, word_point, &font, word_color);
    }
}

void ShowResult::ShowObject_candidate(IplImage* img_, CandidateObject temp_object , int object_ID_,
                                             CvScalar object_color_, int thinkness_)
{
    int point_count = 4;
    CvPoint contour_point4[4];
    CvPoint center_point;
    center_point.x = (int)(temp_object.center_point.x/map_resolution + img_->width/2);
    center_point.y = (int)(img_->height - temp_object.center_point.y/map_resolution - img_->height/2);

    for(int i=0; i<4; i++)
    {
        CvPoint2D32f temp_point;
        temp_point.x = (temp_object.shape.point4[i].x/map_resolution + img_->width/2);
        temp_point.y = (img_->height-1 - temp_object.shape.point4[i].y/map_resolution - map_offset_y);
        contour_point4[i] = cvPointFrom32f(temp_point);
    }
    if (1)
    {
        CvPoint* line_point4 = contour_point4;
        CvScalar object_color = cvScalar(255,0,0);
        cvPolyLine(img_, &line_point4, &point_count, 1, 1, object_color, thinkness_);
    }
    if(0)
    {
        CvFont font;
        cvInitFont(&font, CV_FONT_HERSHEY_PLAIN, 0.8f, 1.0f, 0, 1, 8);

        char file_name_ID[50];
        float temp_pose_head = temp_object.object_box.angle;
        //sprintf(file_name_ID, "%d %.2f %.2f", object_ID_, temp_object.center_point.x, temp_object.center_point.y);
        //sprintf(file_name_ID, "%.1f ", temp_object.pose_heading);
        sprintf(file_name_ID, "%.1f %.1f ", temp_object.center_point.x, temp_object.center_point.y);
        //
        CvScalar word_color = cvScalar( 0, 0, 255 );
        CvPoint word_point;
        word_point.x = temp_object.object_rect.x + temp_object.object_rect.width;
        word_point.y = temp_object.object_rect.y;
        cvPutText(img_, file_name_ID, word_point, &font, word_color);
    }
    if (0)
    {
        int track_index0 = temp_object.track_index0;
        int track_index1 = temp_object.track_index1;
        CvPoint2D32f track_point0_32, track_point1_32, track_point_32;
        track_point0_32.x = (temp_object.shape.point4[track_index0].x/map_resolution + img_->width/2);
        track_point0_32.y = (img_->height - temp_object.shape.point4[track_index0].y/map_resolution - map_offset_y);
        track_point1_32.x = (temp_object.shape.point4[track_index1].x/map_resolution + img_->width/2);
        track_point1_32.y = (img_->height - temp_object.shape.point4[track_index1].y/map_resolution - map_offset_y);
        track_point_32.x = (temp_object.track_point.x/map_resolution + img_->width/2);
        track_point_32.y = (img_->height - temp_object.track_point.y/map_resolution - map_offset_y);

        CvPoint track_point0, track_point1, track_point;
        track_point0 = cvPointFrom32f(track_point0_32);
        track_point1 = cvPointFrom32f(track_point1_32);
        track_point = cvPointFrom32f(track_point_32);
        cvCircle(img_, track_point, 2, cvScalar(0,0,255), 2, 8, 0);

    }

}
void ShowResult::ShowObject_moving(IplImage* img_, MovingObject temp_object , int object_ID_)
{
    CvPoint contour_point4[4];
    CvPoint center_point;
    //得到目标中心点像素坐标
    center_point.x = (int)(temp_object.center_pt.x/map_resolution + img_->width/2);
    center_point.y = (int)(img_->height-1 - temp_object.center_pt.y/map_resolution - img_->height/2);
    //根据目标是否有匹配,计算不同的contour_point4
    if(temp_object.has_match){
      for(int i=0; i<4; i++){
        CvPoint2D32f temp_point;
        temp_point.x = (temp_object.shape.point4[i].x/map_resolution + img_->width/2);
        temp_point.y = (img_->height-1 - temp_object.shape.point4[i].y/map_resolution - map_offset_y);
        contour_point4[i] = cvPointFrom32f(temp_point);
      }
    }
    else{
      for(int i=0; i<4; i++){
        CvPoint2D32f temp_point;
        temp_point.x = (temp_object.contour_rect_pre.point4[i].x/map_resolution + img_->width/2);
        temp_point.y = (img_->height-1 - temp_object.contour_rect_pre.point4[i].y/map_resolution - map_offset_y);
        contour_point4[i] = cvPointFrom32f(temp_point);
      }
      center_point.x = (contour_point4[0].x + contour_point4[2].x)/2;
      center_point.y = (contour_point4[0].y + contour_point4[2].y)/2;
    }

    int point_count = 4;
    if (1)//绘制目标矩形框
    {
        CvPoint* line_point4 = contour_point4;
        CvScalar object_color = cvScalar(0,255,255);//显示黄色
        if (!temp_object.is_updated)
            object_color = cvScalar(0,0,255);//目标未匹配,显示红色
        cvPolyLine(img_, &line_point4, &point_count, 1, 1, object_color, 1);
        //cvLine(img_, contour_point4[0], contour_point4[1], cvScalar(0,255,255), 2, 8, 0);
        //cvCircle(img_, contour_point4[0], 2,cvScalar(0,255,0), 2, 8, 0);
    }
    if(0)//显示车头方向点
    {
        if (temp_object.shape.head_index>-1)
        {
            int head_index = temp_object.shape.head_index;
            int head_pre =  BaseFunction::value_in_threshod_int(head_index -1, 0, 3);
            int head_up = BaseFunction::value_in_threshod_int(head_index + 1, 0, 3);
            int head_diag = 6 - head_index - head_pre - head_up;
            CvPoint head_point;
            head_point.x = (contour_point4[head_index].x + contour_point4[head_up].x)/2;
            head_point.y = (contour_point4[head_index].y + contour_point4[head_up].y)/2;
            cvCircle(img_, contour_point4[head_index], 1,cvScalar(0,255,0), 2, 8, 0);
            cvLine(img_, contour_point4[head_index], contour_point4[head_pre], cvScalar(0,255,0), 2, 8, 0);
        }
    }

    if (0)//显示文字
    {
        CvFont font;
        cvInitFont(&font, CV_FONT_HERSHEY_PLAIN, 0.8f, 1.0f, 0, 1, 8);

        char file_name_ID[50];
        int temp_times = temp_object.track_state.tracked_times;
        if(!temp_object.is_updated)
        {
            temp_times = -temp_object.track_state.missed_times_c;
        }
        sprintf(file_name_ID, "%.2f %.2f",temp_object.shape.line_length0, temp_object.shape.line_length1);
        CvScalar word_color = cvScalar( 0, 0, 255 );
        CvPoint word_point;
        word_point.x = temp_object.object_rect.x + temp_object.object_rect.width/2;
        word_point.y = temp_object.object_rect.y;
        cvPutText(img_, file_name_ID, word_point, &font, word_color);

    }


    if (0)//显示相对运动速度
    {
        float temp_angle = ego_veh_state_current.global_position.heading*pi/180;
        CvPoint temp_v_s;
        CvPoint temp_v_e;
        CvPoint temp_v4_s[4];
        CvPoint temp_v4_e[4];
        float temp_v_x = temp_object.motion_state.v_x_post;
        float temp_v_y = temp_object.motion_state.v_y_post;
        CvPoint2D32f temp_point_f = temp_object.center_point;

        temp_point_f.x = (temp_point_f.x/map_resolution + img_->width/2);
        temp_point_f.y = (img_->height-1 - temp_point_f.y/map_resolution - map_offset_y);
        temp_v_s = cvPointFrom32f(temp_point_f);

        temp_point_f.x = temp_point_f.x + (temp_v_x)/1.5;
        temp_point_f.y = temp_point_f.y - (temp_v_y)/1.5;
        temp_v_e = cvPointFrom32f(temp_point_f);

        for (int m = 0; m < 4; ++m)
        {
            temp_point_f.x = (temp_object.shape.point4[m].x/map_resolution + img_->width/2);
            temp_point_f.y = (img_->height-1 - temp_object.shape.point4[m].y/map_resolution - map_offset_y);
            temp_v4_s[m] = cvPointFrom32f(temp_point_f);
            temp_v_x = temp_object.motion_state.v_x_pt4[m];
            temp_v_y = temp_object.motion_state.v_y_pt4[m];

            temp_point_f.x = temp_point_f.x + (temp_v_x)/map_resolution/1.5;
            temp_point_f.y = temp_point_f.y - (temp_v_y)/map_resolution/1.5;
            temp_v4_e[m] = cvPointFrom32f(temp_point_f);
        }
        cvLine(img_, temp_v_e, temp_v_s, cvScalar(175,0, 175), 1,8,0);

        if(0)
        {
            CvFont font;
            cvInitFont(&font, CV_FONT_HERSHEY_PLAIN, 0.8f, 1.0f, 0, 1, 8);

            char file_name_ID[50];
            memset(file_name_ID, 0, 50);
            float temp_v = 0;//sqrt(temp_x*temp_x + temp_y*temp_y)*1.1 + 0.5;
            //sprintf(file_name_ID, "%d", temp_object.track_state.tracked_times);
            sprintf(file_name_ID, "%d %d %.1f",temp_object.ID_number,temp_object.track_state.tracked_times, temp_v);
            //sprintf(file_name_ID, "%.1f %.1f", temp_v, temp_object.motion_state.pose_head_post*180/pi);
            //sprintf(file_name_ID, "%.1f ", temp_v*map_resolution*3.6 - ego_veh_state_current.fForwardVel*3.6);
            CvScalar word_color = cvScalar( 0, 0, 255 );
            CvPoint word_point;
            word_point.x = temp_object.object_rect.x + temp_object.object_rect.width;
            word_point.y = temp_object.object_rect.y;

            cvPutText(img_, file_name_ID, word_point, &font, word_color);
        }
    }


    if (1)//画速度指示线
    {
        float temp_angle = ego_veh_state_current.global_position.heading*pi/180;
        CvPoint temp_v_s;
        CvPoint temp_v_e;
        CvPoint temp_v4_s[4];
        CvPoint temp_v4_e[4];
        float temp_v_x = temp_object.motion_state_ab.v_x_post;//Kalman滤波输出绝对速度
        float temp_v_y = temp_object.motion_state_ab.v_y_post;
        CvPoint2D32f temp_point_f;//像素坐标系下中心点

        temp_point_f.x = center_point.x;
        temp_point_f.y = center_point.y;
        //绘制速度指示线是从中心点开始画的
        temp_v_s = center_point;
        //将目标全局速度转到车体坐标系
        temp_point_f.x = temp_point_f.x + (temp_v_x*cos(temp_angle) - temp_v_y*sin(temp_angle))/map_resolution/1.5;
        temp_point_f.y = temp_point_f.y - (temp_v_x*sin(temp_angle) + temp_v_y*cos(temp_angle))/map_resolution/1.5;
        temp_v_e = cvPointFrom32f(temp_point_f);

        if (0)
        {
            for (int m = 0; m < 4; ++m)
            {
                temp_point_f.x = (temp_object.shape.point4[m].x/map_resolution + img_->width/2);
                temp_point_f.y = (img_->height-1 - temp_object.shape.point4[m].y/map_resolution - map_offset_y);
                temp_v4_s[m] = cvPointFrom32f(temp_point_f);
                temp_v_x = temp_object.motion_state_ab.v_x_pt4[m];
                temp_v_y = temp_object.motion_state_ab.v_y_pt4[m];

                temp_point_f.x = temp_point_f.x + (temp_v_x*cos(temp_angle) - temp_v_y*sin(temp_angle))/map_resolution/1.5;
                temp_point_f.y = temp_point_f.y - (temp_v_x*sin(temp_angle) + temp_v_y*cos(temp_angle))/map_resolution/1.5;
                temp_v4_e[m] = cvPointFrom32f(temp_point_f);
            }
        }

        cvLine(img_, temp_v_e, temp_v_s, cvScalar(175,0, 175), 1,8,0);

        if(1)//目标周围显示ID号和速度
        {
          CvFont font;
          cvInitFont(&font, CV_FONT_HERSHEY_PLAIN, 0.8f, 0.8f, 0, 1, 8);

          char file_name_ID[50];
          memset(file_name_ID, 0, 50);
          float temp_v = sqrt(temp_v_x*temp_v_x + temp_v_y*temp_v_y);
          //预测部分轨迹拟合出来的速度
          float predict_v = sqrt(pow(temp_object.predict_traj[0].v_x,2)+pow(temp_object.predict_traj[0].v_y,2));
          sprintf(file_name_ID, "%d %.2f",temp_object.target_ID, temp_v);
          CvScalar word_color = cvScalar( 0, 0, 255 );
          CvPoint word_point;
          word_point.x = center_point.x + temp_object.object_rect.width/2;
          word_point.y = center_point.y - temp_object.object_rect.height/2;
          cvPutText(img_, file_name_ID, word_point, &font, word_color);
        }
    }

    if (0)//画历史运动轨迹,需要将历史全局信息转到当前车体坐标系下
    {
        if (temp_object.history_state.history_num > 10 && temp_object.is_updated)
        {
            CvPoint temp_point_pre;
            //TODO,zhanghm: change for (int m=0; m<40; m++)
            for (int m=0; m<temp_object.history_state.history_num; m++)
            {
                CvPoint temp_point4[4];
                CvPoint2D32f temp_point_f;
                //中心点全局坐标
                Point_d temp_point_g = temp_object.history_state.history_center_ab[m];
                //先转到当前车体坐标系下
				BaseFunction::point_global_to_local(temp_point_g.x, temp_point_g.y, ego_veh_state_current, &temp_point_f.x, &temp_point_f.y);
				//再转成像素坐标
                temp_point_f.x = (temp_point_f.x/map_resolution + img_->width/2);
                temp_point_f.y = (img_->height-1 - temp_point_f.y/map_resolution - map_offset_y);
                CvPoint temp_center = cvPointFrom32f(temp_point_f);

//                for (int i = 0; i < 4; ++i)
//                {
//                    temp_point_g = temp_object.history_state.history_rect_ab[m].point4[i];
//					BaseFunction::point_global_to_local(temp_point_g.x, temp_point_g.y, ego_veh_state_current, &temp_point_f.x, &temp_point_f.y);
//                    temp_point_f.x = (temp_point_f.x/map_resolution + img_->width/2);
//                    temp_point_f.y = (img_->height-1 - temp_point_f.y/map_resolution - map_offset_y);
//                    temp_point4[i] = cvPointFrom32f(temp_point_f);
//                }

                CvPoint temp_point = temp_center;
                cvCircle(img_, temp_point, 1, cvScalar(20,225- m*7,100+ m*5),1,8,0);

                //CvPoint* line_point4 = contour_point4_pre;
                //cvPolyLine(img_, &line_point4, &point_count, 1, 1, cvScalar(0,255,0), thinkness_);
                if (m > 0)
                    cvLine(img_, temp_point_pre, temp_point, cvScalar(20,255- m*6,100+ m*5), 1,8,0);
                temp_point_pre = temp_point;
            }
        }
    }


    if (1)//画历史运动轨迹,需要将历史全局信息转到当前车体坐标系下
    {
      CvPoint temp_point_pre;
      for (int m=0; m<temp_object.history_info.size(); ++m){
        CvPoint temp_point4[4];
        CvPoint2D32f temp_point_f;
        //中心点全局坐标
        Point_d temp_point_g = temp_object.history_info[m].history_center_ab;
        //先转到当前车体坐标系下
        BaseFunction::point_global_to_local(temp_point_g.x, temp_point_g.y, ego_veh_state_current, &temp_point_f.x, &temp_point_f.y);
        //再转成像素坐标
        temp_point_f.x = (temp_point_f.x/map_resolution + img_->width/2);
        temp_point_f.y = (img_->height-1 - temp_point_f.y/map_resolution - map_offset_y);
        CvPoint temp_center = cvPointFrom32f(temp_point_f);

        CvPoint temp_point = temp_center;
        cvCircle(img_, temp_point, 1, cvScalar(20,225- m*7,100+ m*5),1,8,0);

        if (m > 0)
          cvLine(img_, temp_point_pre, temp_point, cvScalar(20,255- m*6,100+ m*5), 1,8,0);
        temp_point_pre = temp_point;
      }
    }

    if (0)//显示预测轨迹
    {
        CvPoint temp_point_pre;
        for (int i = 0; i < temp_object.predict_num; ++i)
        {
            Point_d predict_point = temp_object.predict_traj[i].point;
            CvPoint2D32f temp_point_f = temp_object.center_point;
            BaseFunction::point_global_to_local(predict_point.x, predict_point.y, ego_veh_state_current, &temp_point_f.x, &temp_point_f.y);
            temp_point_f.x = (temp_point_f.x/map_resolution + img_->width/2);
            temp_point_f.y = (img_->height-1 - temp_point_f.y/map_resolution - map_offset_y);
            CvPoint temp_point = cvPointFrom32f(temp_point_f);
            cvCircle(img_, temp_point, 1, cvScalar(255,125,0), 1, 8,0);
            if(i > 0)
            {
                cvLine(img_, temp_point, temp_point_pre, cvScalar(255,0,255), 1, 8,0);
            }
            temp_point_pre = temp_point;
        }
    }
    if (0)//显示匹配范围
    {
        CvPoint2D32f temp_point;
        temp_point.x = temp_object.center_point.x/map_resolution + img_->width/2;
        temp_point.y = img_->height-1 - temp_object.center_point.y/map_resolution - map_offset_y;
        CvPoint center_point = cvPointFrom32f(temp_point);
        if (temp_object.object_type < 2)
        {
            cvCircle(img_, center_point, temp_object.match_range.d_radius/map_resolution, cvScalar(0,255,0), 1);
        }
        CvPoint temp_point4[4];
        for (int m = 0; m < 4; ++m)
        {
            CvPoint2D32f temp_point;
            temp_point.x = temp_object.match_range.range_rect4[m].x/map_resolution + img_->width/2;
            temp_point.y = img_->height-1 - temp_object.match_range.range_rect4[m].y/map_resolution - map_offset_y;
            temp_point4[m] = cvPointFrom32f(temp_point);
        }
        CvPoint* ppt_test = temp_point4;

        int point_count = 4;
        cvPolyLine(img_, &ppt_test, &point_count, 1, 1, cvScalar(255,255,0), 1);
    }
}

void ShowResult::Show_word(IplImage* img_, int target_num_, float cost_time_)
{
  CvFont font;
  cvInitFont(&font,CV_FONT_HERSHEY_PLAIN,1.8f,0.8f,0,2,8);

  char name_framecounter[50];
  memset(name_framecounter, 0, 50);
  sprintf(name_framecounter,"frame: %d",frame_counter);
  CvPoint temp_point = cvPoint(5,35);
  cvPutText( img_, name_framecounter, temp_point, &font, cvScalar(255,255,0) );

//  memset(name_framecounter, 0, 50);
  sprintf(name_framecounter,"egoVel: %.1fm/s", ego_veh_state_current.fForwardVel);
  temp_point = cvPoint(5,65);
  cvPutText( img_, name_framecounter, temp_point, &font, cvScalar(255,255,0) );

//  memset(name_framecounter, 0, 50);
  sprintf(name_framecounter,"target: %d", target_num_);
  temp_point = cvPoint(5,95);
  cvPutText( img_, name_framecounter, temp_point, &font, cvScalar(255,255,0) );

//  memset(name_framecounter, 0, 50);
  sprintf(name_framecounter,"time: %.3fs", cost_time_);
  temp_point = cvPoint(5,125);
  cvPutText( img_, name_framecounter, temp_point, &font, cvScalar(255,255,0) );
  if (0)
  {
    memset(name_framecounter, 0, 50);
    sprintf(name_framecounter,"head: %.2f", ego_veh_state_current.global_position.heading);
    temp_point = cvPoint(5,155);
    cvPutText( img_, name_framecounter, temp_point, &font, cvScalar(255,255,0) );

    memset(name_framecounter, 0, 50);
    sprintf(name_framecounter,"dlat: %.2f", ego_veh_state_current.global_position.dLat);
    temp_point = cvPoint(5,185);
    cvPutText( img_, name_framecounter, temp_point, &font, cvScalar(255,255,0) );

    memset(name_framecounter, 0, 50);
    sprintf(name_framecounter,"dlng: %.2f", ego_veh_state_current.global_position.dLng);
    temp_point = cvPoint(5,215);
    cvPutText( img_, name_framecounter, temp_point, &font, cvScalar(255,255,0) );
  }
}

void ShowResult::ShowObjectCubic( boost::shared_ptr<PCLVisualizer> cloud_viewer_, Object_Shape shape_, int ID_,
										 double red_, double green_, double blue_ )
{
	char name_cubic[20], name_word[20],str_target_id[20];
	pcl::PointXYZ text_position;
	if (0)//(temp_object_.pose_heading<85 && temp_object_.pose_heading>10)
	{
		cubic temp_cubic = shape_.cubic_model_3d;
		sprintf(name_cubic, "cubic%d", ID_);
		cloud_viewer_->addCube(temp_cubic.x_min, temp_cubic.x_max, temp_cubic.y_min, temp_cubic.y_max,
							   temp_cubic.z_min, temp_cubic.z_max, red_, green_, blue_, name_cubic, 0);
	}
	else//if (temp_object_.object_type>2)
	{
		for (int m=0; m<4; m++)
		{
			char name_line[20];
			int index_up = BaseFunction::value_in_threshod_int(m+1, 0, 3);
			pcl::PointXYZI pt1, pt2, pt3, pt4;
			pt1.x = shape_.point4[m].x ;
			pt1.y = shape_.point4[m].y ;
			pt1.z = 0;
			pt2.x = shape_.point4[index_up].x ;
			pt2.y = shape_.point4[index_up].y ;
			pt2.z = 0;
			sprintf(name_line, "cline%d-%d", ID_, m*3);
			cloud_viewer_->addLine(pt1, pt2, 1.0, 0, 1.0, name_line);

			pt3.x = shape_.point4[m].x ;
			pt3.y = shape_.point4[m].y ;
			pt3.z = shape_.object_height;
			pt4.x = shape_.point4[index_up].x ;
			pt4.y = shape_.point4[index_up].y ;
			pt4.z = shape_.object_height;
			sprintf(name_line, "cline%d-%d", ID_, m*3+1);
			cloud_viewer_->addLine(pt3, pt4,1.0, 0, 1.0,  name_line);
			sprintf(name_line, "cline%d-%d", ID_, m*3+2);
			cloud_viewer_->addLine(pt1, pt3,1.0, 0, 1.0,  name_line);
		}
	}
}
void ShowResult::Show_word3D( boost::shared_ptr<PCLVisualizer> cloud_viewer_, MovingObject temp_object, int ID_,
								  double red_, double green_, double blue_ )
{
	if (1)
	{
		float ego_angle = ego_veh_state_current.global_position.heading*pi/180;
		pcl::PointXYZI pt1, pt2;
		pt1.x = temp_object.center_point.x ;
		pt1.y = temp_object.center_point.y ;
		pt1.z = temp_object.shape.object_height/2;
		pt2.x = pt1.x + temp_object.motion_state_ab.v_x_post*cos(ego_angle) - temp_object.motion_state_ab.v_y_post*sin(ego_angle);
		pt2.y = pt1.y + temp_object.motion_state_ab.v_x_post*sin(ego_angle) + temp_object.motion_state_ab.v_y_post*cos(ego_angle);
		pt2.z = temp_object.shape.object_height/2;
		char name_arrow[100];
		sprintf(name_arrow, "arrow-%d", ID_);

        cloud_viewer_->addArrow(pt2, pt1, 0.75, 0,0.75, name_arrow);
        //cloud_viewer_->addLine(pt2, pt1, 0.0, 1.0,1.0, name_arrow);
//        pcl::ModelCoefficients coeffs;
//        coeffs.values.clear();
//        coeffs.values.push_back(3);
//        coeffs.values.push_back(3);
//        coeffs.values.push_back(0.0);
//        coeffs.values.push_back(0.0);
//        coeffs.values.push_back(1.0);
//        coeffs.values.push_back(0.0);
//        coeffs.values.push_back(5.0);
//        cloud_viewer_->addCone (coeffs, name_arrow);

		char name_word[100], str_target_id[100];
		sprintf(name_word,"target-%d",  temp_object.ID_number);
		sprintf(str_target_id,"#%d", temp_object.ID_number);
		pt1.x = temp_object.center_point.x ;
		pt1.y = temp_object.center_point.y ;
		pt1.z = temp_object.shape.object_height;

		cloud_viewer_->addText3D(str_target_id, pt1,0.8, 1.0, 0.0, 0.0,name_word,0);
	}
}

void ShowResult::Show_traj3D( boost::shared_ptr<PCLVisualizer> cloud_viewer_, MovingObject temp_object, int ID_,
							  double red_, double green_, double blue_ )
{
	if (1)
	{
		if (temp_object.history_state.history_num > 10 && temp_object.is_updated)
		{
			CvPoint2D32f temp_point_pre;
			for (int m=0; m<20/*temp_object.history_state.history_num*/; m++)
			{
				int point_index0 = temp_object.track_index0;
				int point_index1 = temp_object.track_index0;//temp_object.shape.polar4[0].point_index;

				CvPoint2D32f temp_center;
				CvPoint temp_point4[4];
				CvPoint2D32f temp_point_f;
				Point_d temp_point_g = temp_object.history_state.history_center_ab[m];
				BaseFunction::point_global_to_local(temp_point_g.x, temp_point_g.y, ego_veh_state_current, &temp_point_f.x, &temp_point_f.y);

				temp_center = temp_point_f;
				for (int i = 0; i < 4; ++i)
				{
					temp_point_g = temp_object.history_state.history_rect_ab[m].point4[i];
					BaseFunction::point_global_to_local(temp_point_g.x, temp_point_g.y, ego_veh_state_current, &temp_point_f.x, &temp_point_f.y);
					temp_point4[i] = cvPointFrom32f(temp_point_f);
				}

				CvPoint2D32f temp_point = temp_center;

				//CvPoint* line_point4 = contour_point4_pre;u
				//cvPolyLine(img_, &line_point4, &point_count, 1, 1, cvScalar(0,255,0), thinkness_);
				if (m > 0)
				{
					pcl::PointXYZI pt1, pt2;
					pt1.x = temp_center.x ;
					pt1.y = temp_center.y ;
					pt1.z = 0;
					pt2.x = temp_point_pre.x ;
					pt2.y = temp_point_pre.y ;
					pt2.z = 0;
					char name_line[100];
					sprintf(name_line, "trajline%d-%d", ID_, m);
					cloud_viewer_->addLine(pt1, pt2, 1.0, 0, 1.0, name_line);
				}
				temp_point_pre = temp_point;
			}
		}
	}
}

void ShowResult::Show_moving_vector(IplImage* img_, vector<MovingObject> moving_object_vector_)
{
    for (int i=0; i<moving_object_vector_.size(); i++)
    {
        MovingObject temp_object = moving_object_vector_.at(i);
        ShowObject_moving(img_, temp_object, i);
    }
}
void ShowResult::Show_candidate_vector(IplImage* img_, vector<CandidateObject> candidate_object_vector_)
{

}
void ShowResult::Show_radar_vector(IplImage* img_, vector<Radar_Target> radar_target_vector_)
{
    for (int i=0; i<radar_target_vector_.size(); i++)
    {
        Radar_Target temp_object = radar_target_vector_.at(i);
        if (temp_object.x < 20 && temp_object.x>-20 && temp_object.y<70)
            ShowObject_radar(img_, temp_object, i, cvScalar(255,0,0), 1);
    }
}
