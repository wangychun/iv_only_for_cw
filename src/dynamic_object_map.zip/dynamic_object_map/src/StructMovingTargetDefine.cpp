#include "StructMovingTargetDefine.h"
//***************************  **************************//
float BaseFunction::Angle_atan(float d_x_, float d_y_)
{
  float temp_angle = 0;
  if (d_x_ == 0)
  {
    if (d_y_ > 0 )
      temp_angle = 90;
    if (d_y_ < 0 )
      temp_angle = -90;
  }
  else
  {
    float d_x_y = d_y_ / d_x_;
    temp_angle = atan(d_x_y);
    temp_angle = temp_angle * 180/pi;
  }
  return temp_angle;
}
float BaseFunction::Angle_atan2(float d_x_, float d_y_)//顺时针角度
{
  float temp_angle = (float)atan2(d_y_, d_x_);
  temp_angle = -temp_angle;
  if (temp_angle < 0)
    temp_angle = temp_angle + 2*pi;

  temp_angle = temp_angle*180/pi;
  if (temp_angle > 360)
    temp_angle = 359.999;

  return temp_angle;
}
float BaseFunction::Angle_line2(CvPoint2D32f line_1_, CvPoint2D32f line_2_)
{
  float line1_length = sqrt(line_1_.x*line_1_.x + line_1_.y*line_1_.y);
  float line2_length = sqrt(line_2_.x*line_2_.x + line_2_.y*line_2_.y);
  float line_product = (line_1_.x * line_2_.x + line_1_.y * line_2_.y);
  line_product = line_product / line1_length / line2_length;
  if (line_product>1)
    line_product = 1;

  if (line_product<-1)
    line_product = -1;

  float delta_side_angle0 = acos(line_product)*180/pi;

  return delta_side_angle0;
}
CvPoint2D32f BaseFunction::Point_line2(Line_s line1_, Line_s line2_)
{
  CvPoint2D32f temp_point;
  if ( fabs(line1_.a) < fabs(line1_.b) )
  {
    temp_point.x = line1_.c * line1_.a + line2_.c * line2_.a;
    temp_point.y = (line1_.c - temp_point.x * line1_.a) / line1_.b;
  }
  else
  {
    temp_point.y = line1_.c * line1_.b + line2_.c * line2_.b;
    temp_point.x = (line1_.c - temp_point.y * line1_.b) / line1_.a;
  }
  return temp_point;

}
float BaseFunction::Angle_FitLinePoints(vector<CvPoint2D32f> seed_point_vector_, int point_num_)
{
  CvPoint2D32f* seed_points = (CvPoint2D32f*)malloc( point_num_ * sizeof(seed_points[0]));
  for (int i=0; i<seed_point_vector_.size(); i++)
  {
    CvPoint2D32f seed_point = seed_point_vector_.at(i);
    seed_points[i] = seed_point;//cvPointFrom32f(seed_point);
  }
  float fit_line_param[4];
  memset(fit_line_param, 0 , 4*sizeof(float));
  CvMat pointMat = cvMat( 1, point_num_, CV_32FC2, seed_points );
  cvFitLine( &pointMat, CV_DIST_L1, 1, 0.01, 0.01, fit_line_param );

  float fit_line_angle = atan2(fit_line_param[1] , fit_line_param[0]);

  return fit_line_angle;
}
int BaseFunction::value_in_threshod_int(int value_, int threshod_pre_, int threshod_up_)
{
  int value_return = value_;
  int threshod_length = threshod_up_ - threshod_pre_ + 1;

  if (value_ < threshod_pre_)
  {
    value_return = value_ + threshod_length;
  }
  if (value_ > threshod_up_)
  {
    value_return = value_ - threshod_length;
  }

  return value_return;
}
//给定车体坐标系下点坐标和车辆航向及全局位置,计算相对于全局坐标系的点的坐标
void BaseFunction::point_local_to_global(float x_, float y_, State_Vehicle ego_state_, double* lng_x_, double* lat_y_)
{
  double temp_angle = ego_state_.global_position.heading*pi/180;
  double temp_lng = x_*cos(-temp_angle) - (y_ + V_OFFSET_Y)*sin(-temp_angle) + ego_state_.global_position.dLng;
  double temp_lat = x_*sin(-temp_angle) + (y_ + V_OFFSET_Y)*cos(-temp_angle) + ego_state_.global_position.dLat;
  *lng_x_ = temp_lng;
  *lat_y_ = temp_lat;
}
void BaseFunction::point_global_to_local(double lng_x_, double lat_y_ ,State_Vehicle ego_state_, float* x_, float* y_)
{
  double temp_angle = ego_state_.global_position.heading*pi/180;

  double temp_lng = lng_x_ - ego_state_.global_position.dLng;
  double temp_lat = lat_y_ - ego_state_.global_position.dLat;
  double temp_x = temp_lng*cos(temp_angle) - temp_lat*sin(temp_angle);
  double temp_y = temp_lng*sin(temp_angle) + temp_lat*cos(temp_angle);
  *x_ = temp_x;
  *y_ = temp_y -V_OFFSET_Y;
}
//给定车体坐标系下点坐标(米制单位),计算对应栅格地图像素坐标
void BaseFunction::point_veh_to_img(IplImage* img_, CvPoint* point_, CvPoint2D32f point_f_, float resolution_, int offest_y_)
{
  CvPoint2D32f temp_point_f;
  temp_point_f.x = (point_f_.x/resolution_ + img_->width/2);
  temp_point_f.y = (img_->height-1 - point_f_.y/resolution_ - offest_y_);
  *point_ = cvPointFrom32f(temp_point_f);
}
void BaseFunction::point_img_to_veh(IplImage* img_, CvPoint point_, CvPoint2D32f* point_f_, float resolution_, int offest_y_)
{
  CvPoint2D32f temp_point_f;
  temp_point_f.x = (point_.x - img_->width/2)*resolution_;
  temp_point_f.y = (img_->height-1 - point_.y - offest_y_)*resolution_;
  *point_f_ = temp_point_f;
}

void BaseFunction::Position_Trans_From_ECEF_To_UTM(double latitude,double longitude,double e0, double n0, double *e, double *n)
{
  double WGS84_ECCENTRICITY = (double)0.0818192;                        // e=0.0818192
  double WGS84_EQUATORIAL_RADIUS = (double)6378.137;                    // a=6378.137
  double k0 = (double)0.9996;

  int Zone = (int)(longitude/6) + 1;
  int lonBase = Zone*6 - 3;

  double   vPhi = (double)(1 / sqrt(1-pow(WGS84_ECCENTRICITY * sin(latitude*CV_PI/180.0),2)));
  double  A    = (double)(( longitude - lonBase )*CV_PI/180.0 * cos(latitude*CV_PI/180.0));
  double  sPhi = (double)((1 - pow(WGS84_ECCENTRICITY,2)/4.0 - 3*pow(WGS84_ECCENTRICITY,4)/64.0 - 5*pow(WGS84_ECCENTRICITY,6)/256.0) * latitude*CV_PI/180.0
      - (3*pow(WGS84_ECCENTRICITY,2)/8.0 + 3*pow(WGS84_ECCENTRICITY,4)/32.0 + 45*pow(WGS84_ECCENTRICITY,6)/1024.0) * sin(2*latitude*CV_PI/180.0)
      + (15*pow(WGS84_ECCENTRICITY,4)/256.0 + 45*pow(WGS84_ECCENTRICITY,6)/256.0)* sin(4*latitude*CV_PI/180.0)
      - (35*pow(WGS84_ECCENTRICITY,6)/3072.0) * sin(6*latitude*CV_PI/180.0));
  double  T   = (double)(pow(tan(latitude*CV_PI/180.0),2));
  double  C   = (double)((pow(WGS84_ECCENTRICITY,2)/(1 - pow(WGS84_ECCENTRICITY,2))) * pow(cos(latitude*CV_PI/180.0),2));

  *e = (double)((k0*WGS84_EQUATORIAL_RADIUS*vPhi*(A + (1 - T + C)*pow(A,3)/6.0
      + (5 - 18*T + pow(T,2))*pow(A,5)/120.0))*1000 - e0);
  *n = (double)((k0*WGS84_EQUATORIAL_RADIUS*(sPhi + vPhi * tan(latitude*CV_PI/180.0)*(pow(A,2)/2
      + (5 - T + 9*C + 4*C*C)*pow(A,4)/24.0 + (61 - 58*T + T*T)*pow(A,6)/720.0)))*1000 - n0);
}

void BaseFunction::InitLine_int( int line_num_, Line_int* line_int_ )
{
  for (int i=0; i<line_num_; i++)
  {
    line_int_[i].x1 = 0;
    line_int_[i].y1 = 0;
    line_int_[i].x2 = 0;
    line_int_[i].y2 = 0;
    line_int_[i].line_length= 0;
    line_int_[i].angle= 0;
    line_int_[i].type = 0;
    line_int_[i].left_invalid = 0;
    line_int_[i].right_invalid = 0;
  }
}
void BaseFunction::InitOGM( int ogm_cell_size_, OGM_Cell* rigid_ogm_ )
{
  for (int i = 0; i<ogm_cell_size_; i++)
  {
    rigid_ogm_[i].intensity = 0;
    rigid_ogm_[i].type = UNKNOWN;
    rigid_ogm_[i].min_z = 1000;
    rigid_ogm_[i].max_z = -1000;
    rigid_ogm_[i].average_z = 0;
    rigid_ogm_[i].delta_z = 0;

    rigid_ogm_[i].layers_num =0;
    rigid_ogm_[i].points_num = 0;
    rigid_ogm_[i].endpoint_index = -1;
    rigid_ogm_[i].startpoint_index = 1000000;
    rigid_ogm_[i].startlaser_index = 32;
    rigid_ogm_[i].endlaser_index = -1;

    rigid_ogm_[i].ground_z = 0;
  }
}
void BaseFunction::InitPolarOGM( int polarogm_cell_size_, Polar_Cell* polar_ogm_ )
{
  for (int i = 0; i<polarogm_cell_size_; i++)
  {
    polar_ogm_[i].intensity = 0;
    polar_ogm_[i].type = UNKNOWN;
    polar_ogm_[i].min_z = 1000;
    polar_ogm_[i].max_z = -1000;
    polar_ogm_[i].average_z = 0;
    polar_ogm_[i].delta_z = 0;

    polar_ogm_[i].layers_num =0;
    polar_ogm_[i].points_num = 0;
    polar_ogm_[i].endpoint_index = -1;
    polar_ogm_[i].startpoint_index = 1000000;
    polar_ogm_[i].startlaser_index = 32;
    polar_ogm_[i].endlaser_index = -1;

    //polar_ogm_[i].ground_xy = (i+0.5)*polarogm_radius_resolution;
    polar_ogm_[i].ground_z = 0;
    polar_ogm_[i].grad_m = 0;
    polar_ogm_[i].grad_b = 0;
    polar_ogm_[i].up_link = false;
    polar_ogm_[i].down_link = false;
    polar_ogm_[i].left_link = false;
    polar_ogm_[i].right_link = false;

  }
}
void BaseFunction::InitRegion( int region_cell_size_, Region_Cell* region_ )
{
  for (int i = 0; i<region_cell_size_; i++)
  {
    region_[i].object_num = 0;
    region_[i].object_index_end = -1;
    region_[i].object_index_start = MAX_NUM_TARGET;

    region_[i].layers_num = 0;
    region_[i].startlaser_index = 0;
    region_[i].endlaser_index = -1;
    region_[i].endpoint_index = -1;
    region_[i].startpoint_index = 1000000;

    region_[i].ground_endz = 1000;
    region_[i].ground_startz = 0;
    region_[i].disxy_end = -1;
    region_[i].disxy_start = 50;
    region_[i].ground_type = 0;
  }
}

void BaseFunction::MovingTarget2Send_float2(MovingObject target_send_, Target_output2* target_output_)
{
  //    target_output_->line_num = 4;
  for (int i = 0; i < 4; ++i)//目标矩形框四个点
  {
    target_output_->line_point[i].x = target_send_.contour_rect_ab.point4[i].x - target_send_.center_point_ab.x;
    target_output_->line_point[i].y = target_send_.contour_rect_ab.point4[i].y - target_send_.center_point_ab.y;
  }
  //中心点全局位置
  target_output_->center_point.x = target_send_.center_point_ab.x;
  target_output_->center_point.y = target_send_.center_point_ab.y;
  //TODO:zhanghm::下面几个属性有用吗？
  target_output_->object_high = target_send_.shape.object_height;
  target_output_->object_type = target_send_.object_type;

  target_output_->ID_number = target_send_.ID_number;
  //TODO:发送目标是不是没必要管它有没有匹配目标？？
  target_output_->is_updated = target_send_.is_updated;
  //TODO:跟踪次数这些属性是不是也没什么很大必要？？可以转成目标置信度或其他等级指标
  target_output_->tracked_times = target_send_.track_state.tracked_times;
  target_output_->dangerous_level = target_send_.dangerous_level;

  target_output_->predict_num = target_send_.predict_num;
  for (int i = 0; i < target_output_->predict_num; ++i)
  {
    target_output_->predict_traj[i] = target_send_.predict_traj[i];
  }

  //在干嘛？？？
  target_output_->history_num = target_send_.track_state.tracked_times + 1 ;
  target_output_->history_num = min(target_output_->history_num, 20);
  if (target_send_.send_times > 1 )
    target_output_->history_num = 2;
  //目标历史信息
  for (int i = 0; i < target_output_->history_num; ++i)
  {
//    target_output_->history_traj[i].history_time = target_send_.history_state.history_time[i];
//    target_output_->history_traj[i].history_center = target_send_.history_state.history_center_ab[i];

    target_output_->history_traj[i].history_time = target_send_.history_info.at(i).time_stamp;
    target_output_->history_traj[i].history_center = target_send_.history_info.at(i).history_center_ab;

    Contour_Rect_d temp_rect_d = target_send_.history_state.history_rect_ab[i];
    if(1)
    {
      int index4[4];
      float min_x = 10000000;

      for (int m =0; m<4; m++)
      {
        float temp_x = temp_rect_d.point4[m].x - target_output_->history_traj[i].history_center.x;
        if (temp_x < min_x)
        {
          min_x = temp_x;
          index4[0] = m;
        }
      }
      index4[2] = value_in_threshod_int(index4[0] + 2 ,0, 3) ;

      for (int m =0; m<4; m++)
      {
        if ( !(m ==index4[0]  || m ==index4[2]))
        {
          index4[1] = m;
          index4[3] = m + 2;
          if(temp_rect_d.point4[m].y < temp_rect_d.point4[m + 2].y)
          {
            index4[1] = m + 2;
            index4[3] = m;
          }
          break;
        }
      }
      for (int m =0; m<4; m++)
      {
        int index = index4[m];
        temp_rect_d.point4[m] = target_send_.history_state.history_rect_ab[i].point4[index];
      }
    }
    target_output_->history_traj[i].history_rect = temp_rect_d;

  }//end for (int i = 0; i < target_output_->history_num; ++i)
}
