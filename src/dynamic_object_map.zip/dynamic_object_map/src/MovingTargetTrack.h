/*======================================================================
 * Author   : Weijie Meijie
 * Email    :
 * Maintainer:  Haiming Zhang
 * Version  :
 * Copyright    :
 * Descriptoin  : 目标跟踪主功能类，与外界接口，使用其他功能类，共同完成
 *                1、点云栅格地图生成
 *                2、目标检测
 *                3、目标跟踪
 *                等不同任务
 * References   :
======================================================================*/
#pragma once
#include <stdio.h>
#include <string>
#include <typeinfo>
#include "multi_object_tracking.h"//TODO,应该以一个类为主
#include "StructMovingTargetDefine.h"
#include "detect/VLaneLocalization.h"
#include "detect/TargetDetection.h"
#include "detect/MapOGM.h"
//#include <dynamic_object/src/detect/MapOGM.h>
#include  "velodyne/data_types.hpp"

#include <opencv2/opencv.hpp>
#include "fstream"
#include "iostream"


using namespace std;
using namespace boost;

namespace dynamic_map{

class MovingTargetTrack
{
public:
  //constructors
  MovingTargetTrack();
  ~MovingTargetTrack();
  void Fit_vel_ego();

  void MovingTarget2Send_float2(MovingObject target_send_, Target_output2* target_output_);

  void ShowViewerCloudPoints( boost::shared_ptr<PCLVisualizer> cloud_viewer_, pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_show_,
      char cloudname[], double color_red_, double color_green_, double color_blue_ );

  void OGM_Generate();
  void TargetDetection();//目标检测

  void Show_Result_3D(boost::shared_ptr<PCLVisualizer> cloud_viewer_);

  void ProcessFrame();
  /************************************
   * zhanghm: add 20180525
   **********************************/

  void SetCloudInput(pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_in);
  void DrawResult();
  void Show_Result_2D(double elapsed_time = 0.0);

  //get and set functions
  const IplImage* get_img_ogm(){return img_ogm;}
  const Polar_Cell* get_polar_ogm(int& polar_cell_size){polar_cell_size = polarogm_cell_size;
                                                        return polar_ogm;}
  const OGM_Cell* get_rigid_refined_ogm(int& rigid_cell_size){rigid_cell_size = refineogmcell_size; return rigid_refined_ogm;}
private:
  void PreProcess();//生成地面栅格
  /*!
   *
   * @param xv[in] 车体坐标系点
   * @param yv[in]
   * @param row[out] 图像坐标系点
   * @param col[out]
   * @return
   */
  bool get_image_coord(const float& xv,const float& yv,int& row,int& col);


public:
  pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_input;
  int laserscanner_num;

  std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> inputclouds;
  std::vector<pcl::PointXYZI> lidarpropertys;

  //
  float refineogm_width;//Unit: m
  float refineogm_height;
  float refineogm_offset_y;
  float refineogm_resolution;
  int refineogmwidth_cell;
  int refineogmheight_cell;
  int refineogmcell_size;
  OGM_Cell* rigid_refined_ogm;//!整个栅格地图cell数组指针

  //
  float largeogm_width;
  float largeogm_height;
  float largeogm_offset_y;
  float largeogm_resolution;
  int largeogmwidth_cell;
  int largeogmheight_cell;
  int largeogmcell_size;
  OGM_Cell* large_rigid_ogm;

  //polar_ogm
  float polarogm_radius_resolution;
  float polarogm_angle_resolution;
  float polarogm_radius; //2.5m-60m
  float polarogm_angle;

  int polarogm_radius_cell;
  int polarogm_angle_cell;
  int polarogm_cell_size;
  Polar_Cell* polar_ogm;
  Line_s* polar_fit_line;

  float largepolar_radius_resolution;
  float largepolar_angle_resolution;
  float largepolar_radius;
  float largepolar_angle;

  int largepolar_radius_cell;
  int largepolar_angle_cell;
  int largepolar_cell_size;
  Polar_Cell* largepolar_ogm;

  float virtual_line_resolution;
  int virtual_line_num;
  Line_int* virtual_line;

  //
  float regionogm_radius_resolution;
  float regionogm_angle_resolution;
  float regionogm_radius;
  float regionogm_angle;
  int regionogm_radius_cell;
  int regionogm_angle_cell;
  int regionogm_cell_size;

  Region_Cell* region_ogm;


  IplImage* img_ogm;//!refineogm地图,单通道
  IplImage* img_elevation;
  IplImage* img_history;//与img_ogm尺寸一致,单通道
  IplImage* img_moving_object;//与img_ogm尺寸一致,3通道
  IplImage* img_target_fusion;//最终融合图像,考虑到毫米波雷达检测距离可能较远,该图像在车前多加了100个像素

  int map_width;
  int map_height;
  int map_offset_y;
  float map_resolution;
  CvPoint ego_veh_position;//本车在栅格地图中的位置

  bool OGM_update;
  int frame_counter;
  int frame_counter_update;
  double time_stamp;

  State_Vehicle ego_veh_state_current;
  State_Vehicle ego_veh_state_pre[HISTORY_NUM];

  State_Vehicle ego_veh_state_gps;
  State_Vehicle ego_veh_state_lidar;
  float ego_veh_vel_fit;

  vector<CandidateObject> fusion_object_vector;

  int target_detect_new;
  vector<MovingObject> moving_object_vector;//跟踪目标序列
  vector<MovingObject> moving_object_vector_send;//发送给规划的跟踪目标向量
  MovingTargetSend moving_target_send;//最终要发送的目标
  Radar_data radar;
  vector<Radar_Target> radar_target_vector;

  //GroundBackModel groundback_build;
  TargetDetecter target_detecter;
  OGMMappingUtils ogm_map;
  ShowResult show_result;

  double total_cost_time;

  CvVideoWriter*  output_img_moving;
  CvVideoWriter*  output_img_moving1;

  char* file_name_pre;

  /************************************
   * zhanghm: add 20180525
   **********************************/
  cv::Mat origin_lidar_map_; //原始雷达点云投影图
  pcl::PointCloud<pcl::PointXYZI> heightdiffpointcloud_;//去除地面的点云
  MultiObjectTracking multi_track_;
};
}





