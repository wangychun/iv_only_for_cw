#include "MovingTargetTrack.h"

namespace dynamic_map{

MovingTargetTrack::MovingTargetTrack()
{
  moving_object_vector.clear();
  moving_object_vector_send.clear();

  moving_target_send.target_num = 0;
  memset(&radar, 0, sizeof(Radar_data));
  radar_target_vector.clear();

  frame_counter = 0;
  memset(&ego_veh_state_current, 0, sizeof(State_Vehicle));

  ego_veh_vel_fit = 0;
  /**************初始化栅格地图相关变量*****************/
  refineogm_width = OGM_WIDTH;//80m
  refineogm_height = OGM_HEIGHT;//100m
  refineogm_offset_y = OFFSET_Y;//50m
  refineogm_resolution = OGM_RESOLUTION;//0.2
  refineogmwidth_cell = boost::math::round(refineogm_width / refineogm_resolution) + 1;//401
  refineogmheight_cell = boost::math::round(refineogm_height / refineogm_resolution) + 1;//501
  refineogmcell_size = refineogmwidth_cell * refineogmheight_cell;//321201
  rigid_refined_ogm = new OGM_Cell[refineogmcell_size];

  largeogm_width = 20;//80
  largeogm_height = 40;//100
  largeogm_offset_y = 10;
  largeogm_resolution = 1;//
  largeogmwidth_cell = boost::math::round(largeogm_width / largeogm_resolution) + 1;//501
  largeogmheight_cell = boost::math::round(largeogm_height / largeogm_resolution) + 1;//501
  largeogmcell_size = largeogmwidth_cell * largeogmheight_cell;//321201
  large_rigid_ogm = new OGM_Cell[largeogmcell_size];

  //初始化栅格地图图像
  img_ogm = cvCreateImage(cvSize(refineogmwidth_cell, refineogmheight_cell),8,1);//401x501
  img_history = cvCreateImage(cvSize(refineogmwidth_cell, refineogmheight_cell),8,1);
  img_moving_object = cvCreateImage(cvSize(refineogmwidth_cell, refineogmheight_cell), 8, 3);//激光雷达运动目标图
  img_target_fusion = cvCreateImage(cvSize(refineogmwidth_cell, refineogmheight_cell+100), 8, 3);//毫米波雷达融合图
  cvZero(img_ogm);
  cvZero(img_target_fusion);
  cvZero(img_moving_object);
  cvSet(img_moving_object, cvScalar(215,215,215));
  /**************初始化栅格地图相关变量*****************/

  map_width = img_ogm->width;//401
  map_height = img_ogm->height;//501
  map_offset_y = refineogm_offset_y/refineogm_resolution;//250
  map_resolution = refineogm_resolution;
  ego_veh_position.x = map_width/2;
  ego_veh_position.y = map_height-1 - map_offset_y;

  //polar_ogm 极坐标栅格地图
  polarogm_radius_resolution = 0.5f;//半径方向(径向)分辨率
  polarogm_angle_resolution = 1.0f; //角度分辨率
  polarogm_radius = 60.0f;         //0-50m
  polarogm_angle = 360.0f;         //

  polarogm_radius_cell = boost::math::round( polarogm_radius/ polarogm_radius_resolution );
  polarogm_angle_cell = boost::math::round( polarogm_angle/ polarogm_angle_resolution );
  polarogm_cell_size = polarogm_angle_cell * polarogm_radius_cell;
  polar_ogm = new Polar_Cell[polarogm_cell_size];
  polar_fit_line = new Line_s[polarogm_angle_cell];

  //绘制射线的一些参数
  virtual_line_resolution = polarogm_angle_resolution;//现在是1度一根射线
  virtual_line_num  = polarogm_angle_cell;//360度除以1度得到360根
  virtual_line = new Line_int[virtual_line_num];//射线结构体
  BaseFunction::InitLine_int(polarogm_angle_cell, virtual_line);

  largepolar_radius_resolution = 1.0f;
  largepolar_angle_resolution = 3.0f;
  largepolar_radius = 30.0f;         //0-50m
  largepolar_angle = 360.0f;         //

  largepolar_radius_cell = boost::math::round( largepolar_radius/ largepolar_radius_resolution );
  largepolar_angle_cell = boost::math::round( largepolar_angle/ largepolar_angle_resolution );
  largepolar_cell_size = largepolar_angle_cell * largepolar_radius_cell;
  largepolar_ogm = new Polar_Cell[largepolar_cell_size];
  memset( ego_veh_state_pre, 0, HISTORY_NUM*sizeof(State_Vehicle) );

  laserscanner_num = 32;

  //给ShowResult类初始化
  show_result.ShowTrackingResult( img_moving_object, refineogm_resolution, refineogm_offset_y, &moving_object_vector );

  char file_name[100];
  sprintf(file_name, "/home/mwj/rostest/rviz_0423/data/output.avi");
  output_img_moving = cvCreateVideoWriter(file_name, CV_FOURCC('D','I','V','X'), 9,
      cv::Size(img_target_fusion->width, img_target_fusion->height));

}

MovingTargetTrack::~MovingTargetTrack()
{
  delete[] large_rigid_ogm;
  delete[] rigid_refined_ogm;
  delete[] polar_ogm;
  delete[] largepolar_ogm;

  delete[] polar_fit_line;
  delete[] virtual_line;

  cvReleaseImage(&img_ogm);
  cvReleaseImage(&img_history);
  cvReleaseImage(&img_moving_object);
  cvReleaseImage(&img_target_fusion);

  //cvReleaseVideoWriter(&output_img_moving);
  // cvReleaseVideoWriter(&output_img_moving1);
}

void MovingTargetTrack::SetCloudInput(pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_in)
{
  total_cost_time = 0;
  timer t_cloud_get;
  this->cloud_input = cloud_in;
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_temp(new pcl::PointCloud<pcl::PointXYZ>);
  pcl::copyPointCloud(*cloud_in,*cloud_temp);
  multi_track_.SetCloudInput(cloud_temp);
  cout<<" t_cloud_get "<<t_cloud_get.elapsed()<<endl;
  total_cost_time += t_cloud_get.elapsed();
}
void MovingTargetTrack::PreProcess()
{
  multi_track_.ProcessFrame();//去除地面点云
  pcl::PointCloud<pcl::PointXYZ>::Ptr elevated_cloud = multi_track_.getElevatedCloud();
  pcl::PointCloud<pcl::PointXYZRGB>::Ptr clustered_cloud = multi_track_.getClusteredCloud();
  pcl::copyPointCloud(*clustered_cloud,heightdiffpointcloud_);
}

void MovingTargetTrack::Fit_vel_ego()
{
  int history_num  = min(frame_counter, 10);
  CvPoint2D32f* v_x_seed = (CvPoint2D32f*)malloc( history_num * sizeof(v_x_seed[0]));
  CvPoint2D32f* v_y_seed = (CvPoint2D32f*)malloc( history_num * sizeof(v_y_seed[0]));
  for (int i=0; i<history_num; i++)
  {
    v_x_seed[i].x = (ego_veh_state_pre[i].time_stamp - ego_veh_state_pre[history_num-1].time_stamp)*10;
    v_y_seed[i].x = (ego_veh_state_pre[i].time_stamp - ego_veh_state_pre[history_num-1].time_stamp)*10;
    v_x_seed[i].y = (ego_veh_state_pre[i].global_position.dLng
        - ego_veh_state_pre[history_num-1].global_position.dLng)*2 ;
    v_y_seed[i].y = (ego_veh_state_pre[i].global_position.dLat
        - ego_veh_state_pre[history_num-1].global_position.dLat)*2 ;
  }
  float fit_v_x_param[4];
  memset(fit_v_x_param, 0 , 4*sizeof(float));
  CvMat pointMat_x = cvMat( 1, history_num, CV_32FC2, v_x_seed );
  cvFitLine( &pointMat_x, CV_DIST_L1, 1, 0.01, 0.01, fit_v_x_param );

  float fit_v_y_param[4];
  memset(fit_v_y_param, 0 , 4*sizeof(float));
  CvMat pointMat_y= cvMat( 1, history_num, CV_32FC2, v_y_seed );
  cvFitLine( &pointMat_y, CV_DIST_L1, 1, 0.01, 0.01, fit_v_y_param );

  float temp_v_x = 5*fit_v_x_param[1]/ fit_v_x_param[0];
  float temp_v_y = 5*fit_v_y_param[1]/ fit_v_y_param[0];
  ego_veh_vel_fit = sqrt(temp_v_x*temp_v_x + temp_v_y*temp_v_y);
}

void MovingTargetTrack::ProcessFrame()
{

  //开始处理
  std::cout<<"***************frame_counter: "<<frame_counter<<"************************"<<std::endl;
  timer t_preprocess;
  this->PreProcess(); //地面点云移除
  total_cost_time += t_preprocess.elapsed();
  std::cout<<"t_preprocess: "<<t_preprocess.elapsed()<<endl;
  std::cout<<"-----------------Begin OGM_Generate--------------------------------"<<std::endl;
  this->OGM_Generate();//生成栅格地图
  std::cout<<"-----------------End OGM_Generate----------------------------------"<<std::endl;
  std::cout<<"-----------------Begin TargetDetection-----------------------------"<<std::endl;
  this->TargetDetection();//目标检测
  std::cout<<"-----------------End TargetDetection-------------------------------"<<std::endl;
}

//***************************** basic function ***********************//
void MovingTargetTrack::OGM_Generate()
{
  timer t_ogm;
  frame_counter++;
  //给栅格地图赋初始属性
  BaseFunction::InitOGM(largeogmcell_size, large_rigid_ogm);
  BaseFunction::InitOGM(refineogmcell_size, rigid_refined_ogm);
  BaseFunction::InitPolarOGM(polarogm_cell_size, polar_ogm);
  memset(polar_fit_line, 0, polarogm_angle_cell);
  OGM_update = false;

  if (cloud_input->points.size()>0)//(cloud_input)
  {
    OGM_update = true;
    cvCopy(img_ogm, img_history);
    cvZero(img_moving_object);
    cvZero(img_ogm);
    int start_laser_index = 0;
    int end_laser_index = 63;
    int polar_ogm_method = 1;

    if (1)
    {
      ogm_map.CloudLser2PolarOGM( heightdiffpointcloud_.makeShared(), laserscanner_num, polar_ogm_method, start_laser_index, end_laser_index,
          polar_ogm, polarogm_angle, polarogm_radius, polarogm_angle_resolution,
          polarogm_radius_resolution);

      ogm_map.CloudLser2PolarOGM( heightdiffpointcloud_.makeShared(), laserscanner_num, polar_ogm_method, start_laser_index, end_laser_index,
          largepolar_ogm, largepolar_angle, largepolar_radius, largepolar_angle_resolution,
          largepolar_radius_resolution);

      ogm_map.CloudLser2GridOGM( heightdiffpointcloud_.makeShared(), laserscanner_num, start_laser_index, end_laser_index,
          rigid_refined_ogm, refineogm_width, refineogm_height, refineogm_resolution,
          refineogm_offset_y );// refine ogm
          ogm_map.CloudLser2GridOGM( heightdiffpointcloud_.makeShared(), laserscanner_num, start_laser_index, end_laser_index,
              large_rigid_ogm, largeogm_width, largeogm_height, largeogm_resolution,
              largeogm_offset_y );// refine ogm
    }

    if (1)
    {
      //给栅格地图cell赋予type属性,UNKNOWN,RIGIDNOPASSABLE etc.
      ogm_map.GridOGM_Ground( polar_ogm, polarogm_angle, polarogm_radius, polarogm_angle_resolution,
          polarogm_radius_resolution, rigid_refined_ogm, refineogm_width,
          refineogm_height, refineogm_resolution, refineogm_offset_y );
    }

    //给img_ogm图像赋值
    for (int i = 0; i < img_ogm->height;i++){
      for (int j = 0; j < img_ogm->width;j++){
        //将RIGIDNOPASSABLE属性的占据栅格在img_ogm上用白色点表示
        if (rigid_refined_ogm[i*refineogmwidth_cell + j].type == RIGIDNOPASSABLE){
          img_ogm->imageData[(img_ogm->height - i - 1)*img_ogm->widthStep + j] = 255;//intensity;
        }
      }
    }
    cvCvtColor(img_ogm, img_moving_object, CV_GRAY2BGR);//255的每个像素变成255,255,255
  }//end if (cloud_input->points.size()>0)

  IplImage* img_cpy = cvCreateImage(cvSize(refineogmwidth_cell, refineogmheight_cell), 8, 1);
  cvCopy(img_ogm,img_cpy);
  cvNamedWindow("img_cpy",CV_WINDOW_NORMAL);
  cvShowImage("img_cpy",img_cpy);
  cvWaitKey(10);
  total_cost_time += t_ogm.elapsed();
  cout<< " t_ogm: " << t_ogm.elapsed() <<endl;
  cvReleaseImage(&img_cpy);
}


void MovingTargetTrack::TargetDetection()
{	
  timer t_detect;
  BaseFunction::InitLine_int(virtual_line_num, virtual_line);//初始化virtual_line数组
  fusion_object_vector.clear();//清空上一次检测到的所有目标
  if (OGM_update && frame_counter>1)
  {
    target_detecter.is_show_img = true;
    target_detecter.ego_veh_state_current = ego_veh_state_current;//传入本车位姿信息
    target_detecter.MapInput( frame_counter,refineogm_width, refineogm_height, refineogm_offset_y, refineogm_resolution,
        polarogm_angle, polarogm_radius, polarogm_angle_resolution,
        polarogm_radius_resolution, virtual_line_num, virtual_line_resolution);
    /*************************************************************************************
     *                        对二值栅格地图完成目标检测功能
     * 检测结果存在fusion_object_vector中,绘制的射线相关信息存在virtual_line中
     ************************************************************************************/
    target_detecter.Detect(img_ogm, rigid_refined_ogm, refineogmcell_size, polar_ogm, polarogm_cell_size,
        &fusion_object_vector, virtual_line);
  }
  total_cost_time +=  t_detect.elapsed();

  cout<< " t_detect: " << t_detect.elapsed() << endl;

}

bool MovingTargetTrack::get_image_coord(const float& xv,const float& yv,int& row,int& col)
{
  //计算在图像位置
  //栅格地图预先设置好
  col = (int)((xv + refineogm_width/2) / refineogm_resolution);
  row = refineogmheight_cell - 1 - (int)((yv + refineogm_offset_y) / refineogm_resolution);
  if(col < 0||col>=refineogmwidth_cell||row<0||row>=refineogmheight_cell)
    return false;
  return true;//在图像范围内,有效
}

void MovingTargetTrack::Show_Result_2D(double elapsed_time)
{
  timer t_show_2D;
  cout<<" --------------t_show_2D.elapsed() before: "<<t_show_2D.elapsed()<<endl;
  //    show_result.Show_word(img_moving_object, moving_target_send.target_num, total_cost_time);
  show_result.Show_word(img_target_fusion, moving_target_send.target_num, elapsed_time);
  cout<<" --------------t_show_2D.elapsed() after: "<<t_show_2D.elapsed()<<endl;

  cvNamedWindow("img_target_fusion",CV_WINDOW_NORMAL);
  cvShowImage("img_target_fusion", img_target_fusion);
//  cvNamedWindow("img_moving_object",0);
//  cvShowImage("img_moving_object", img_moving_object);
//  cvWaitKey(1);
  cout<< " t_show_2DDDDDDD: "<<  t_show_2D.elapsed() << endl;
  cout<<" --------------t_total_time: "<<total_cost_time<<endl;
}

void MovingTargetTrack::DrawResult(){
  timer t_show_2D;
  /************************
   * 画原始雷达点的栅格地图
   ***********************/
//  origin_lidar_map_ = cv::Mat::zeros(refineogmheight_cell,refineogmwidth_cell,CV_8UC3);
//  for(int i = 0;i<cloud_input->size();++i)
//  {
//    //获得每个点的属性
//    float x = cloud_input->points[i].x;
//    float y = cloud_input->points[i].y;
//    float z = cloud_input->points[i].z;
//    //计算在图像位置
//    int row,col;
//    if(!get_image_coord(x,y,row,col))
//      continue;
//    origin_lidar_map_.at<cv::Vec3b>(row,col) = cv::Vec3b(0,255,0);
//  }
//  cv::namedWindow("origin_lidar_map",CV_WINDOW_NORMAL);
//  cv::imshow("origin_lidar_map",origin_lidar_map_);

//  /************************
//   * 画滤除地面后雷达点的栅格地图
//   ***********************/
//  cv::Mat diff_height = cv::Mat::zeros(refineogmheight_cell,refineogmwidth_cell,CV_8UC3);
//  for(int i = 0;i<heightdiffpointcloud_.size();++i)
//  {
//    //获得每个点的属性
//    float x = heightdiffpointcloud_.points[i].x;
//    float y = heightdiffpointcloud_.points[i].y;
//    float z = heightdiffpointcloud_.points[i].z;
//    //计算在图像位置
//    int row,col;
//    if(!get_image_coord(x,y,row,col))
//      continue;
//    diff_height.at<cv::Vec3b>(row,col) = cv::Vec3b(0,255,0);
//  }
//  cv::namedWindow("diff_height",CV_WINDOW_NORMAL);
//  cv::imshow("diff_height",diff_height);


  int temp_map_offest_y = boost::math::round(refineogm_offset_y / refineogm_resolution);
  cvZero(img_target_fusion);
  show_result.ego_veh_state_current = ego_veh_state_current;
  show_result.frame_counter = frame_counter;
  show_result.ShowEgoVehicle(img_moving_object, temp_map_offest_y, refineogm_resolution, EGO_CAR_WIDTH, EGO_CAR_LENGTH);
  show_result.ShowEgoVehicle(img_target_fusion, temp_map_offest_y, refineogm_resolution, EGO_CAR_WIDTH, EGO_CAR_LENGTH);
  //    IplImage* img_cpy = cvCreateImage(cvSize(refineogmwidth_cell, refineogmheight_cell), 8, 3);
  //    cvCopy(img_moving_object,img_cpy);
  //    cvNamedWindow("img_cpy2",CV_WINDOW_NORMAL);
  //    cvShowImage("img_cpy2",img_cpy);
  //    cvWaitKey(10);
  //    cvReleaseImage(&img_cpy);

  if (0)//send target
  {
    show_result.Show_moving_vector(img_moving_object, moving_object_vector_send);
  }


  if (1)
  {
    CvPoint rect_point0;
    rect_point0.x = 0;
    rect_point0.y = 100;
    int rect_width = img_moving_object->width;
    int rect_length = img_moving_object->height;
    CvRect rect_near = cvRect(rect_point0.x, rect_point0.y, rect_width, rect_length);
    cvSetImageROI(img_target_fusion, rect_near);
    cvCopy(img_moving_object, img_target_fusion);
    cvResetImageROI(img_target_fusion);
  }
  if (0)
  {
    cvZero(img_moving_object);
    cvCvtColor(img_ogm, img_moving_object, CV_GRAY2BGR);
    show_result.ShowEgoVehicle(img_moving_object, temp_map_offest_y, refineogm_resolution, EGO_CAR_WIDTH, EGO_CAR_LENGTH);

    for (int i=0; i<moving_object_vector.size(); i++){
      MovingObject temp_object = moving_object_vector.at(i);
      //if (temp_object.is_updated && temp_object.motion_behavior>0 && temp_object.object_type>0)
      show_result.ShowObject_moving(img_moving_object,temp_object, i);
    }
    for (int i=0; i<fusion_object_vector.size(); i++){
      CandidateObject temp_object = fusion_object_vector.at(i);
      //show_result.ShowObject_candidate(img_moving_object, temp_object, i, cvScalar(255,0,0), 1);
      CvPoint2D32f temp_center_f;
      temp_center_f.x = (temp_object.center_point.x)/map_resolution + img_moving_object->width/2;
      temp_center_f.y = img_moving_object->height-1 - temp_object.center_point.y/map_resolution - map_offset_y;
      CvPoint temp_center = cvPointFrom32f(temp_center_f);
      if (temp_object.match_index<0){
        cvCircle(img_moving_object, temp_center, 1, cvScalar(255,0,0), 2, 8,0);//蓝色
      }
      else{
        cvCircle(img_moving_object, temp_center, 1, cvScalar(0,255,0), 2, 8,0);//绿色
      }
    }
  }

  if (0)//radar
  {
    show_result.Show_radar_vector(img_target_fusion, radar_target_vector);
  }

  /************************************************
   * 画本车运动轨迹(相当于把历史帧本车全局位置投到当前帧下)
   ************************************************/
  if (1)//ego traj
  {
    CvPoint ego_point0 = cvPoint(img_target_fusion->width/2, img_target_fusion->height - map_offset_y);
    for (int i=0; i<50; i++)
    {
      CvPoint2D32f ego_point1_32;
      float temp_x = 0;
      float temp_y = 0;
      BaseFunction::point_global_to_local(ego_veh_state_pre[i].global_position.dLng, ego_veh_state_pre[i].global_position.dLat,
          ego_veh_state_current, &temp_x, &temp_y);

      ego_point1_32.x = temp_x/map_resolution + img_target_fusion->width/2;
      ego_point1_32.y = img_target_fusion->height - temp_y/map_resolution - map_offset_y;

      CvPoint ego_point1 = cvPointFrom32f(ego_point1_32);
      //            cvLine(img_target_fusion, ego_point0, ego_point1, cvScalar(0,255,0), 1,8,0);
      cvCircle(img_target_fusion, ego_point1, 1, cvScalar(255,255,0),1,8,0);

      ego_point0 = ego_point1;
    }
  }
  if (0)
  {
    show_result.ShowPolarOGM(img_moving_object, polar_ogm, polarogm_angle, polarogm_radius,
        polarogm_angle_resolution, polarogm_radius_resolution);
  }

//  cvNamedWindow("img_moving_object",0);
//  cvShowImage("img_moving_object", img_moving_object);
//  cvWaitKey(1);
  cout<< " t_show_2D: "<<  t_show_2D.elapsed() << endl;
  total_cost_time += t_show_2D.elapsed();
  cout<<" --------------t_total_time: "<<total_cost_time<<endl;
}

void MovingTargetTrack::Show_Result_3D(boost::shared_ptr<PCLVisualizer> cloud_viewer_)
{
  timer t_show_3D;

  if (0)
  {
    for (int i = 0; i < fusion_object_vector.size(); i++)
    {
      CandidateObject temp_candidate = fusion_object_vector.at(i);
      show_result.ShowObjectCubic(cloud_viewer_, temp_candidate.shape, i, 0.0, 1.0, 0.0);
    }
  }
  if (0)
  {
    for (int i=0; i<moving_object_vector.size(); i++)
    {
      MovingObject temp_moving_object = moving_object_vector.at(i);
      if (temp_moving_object.is_updated && temp_moving_object.track_state.tracked_times>5)
        show_result.ShowObjectCubic(cloud_viewer_, temp_moving_object.shape, i, 0.0, 1.0, 0.0);

    }
  }
  for (int m=0; m<moving_object_vector_send.size(); m++)
  {
    MovingObject temp_object = moving_object_vector_send.at(m);
    if (temp_object.is_updated)
    {
      if(1)
      {
        Point2D rect_point4[4];
        memcpy(rect_point4, temp_object.shape.point4, 4*sizeof(Point2D) );
        float min_x = min( min(rect_point4[0].x, rect_point4[1].x), min(rect_point4[2].x, rect_point4[3].x) );
        float max_x = max( max(rect_point4[0].x, rect_point4[1].x), max(rect_point4[2].x, rect_point4[3].x) );
        float min_y = min( min(rect_point4[0].y, rect_point4[1].y), min(rect_point4[2].y, rect_point4[3].y) );
        float max_y = max( min(rect_point4[0].y, rect_point4[1].y), max(rect_point4[2].y, rect_point4[3].y) );
        int min_col = (int)(min_x/refineogm_resolution + refineogmwidth_cell/2) -1;
        int max_col = (int)(max_x/refineogm_resolution + refineogmwidth_cell/2) + 1;
        int min_row = (int)(min_y/refineogm_resolution + refineogm_offset_y/refineogm_resolution) - 1;
        int max_row = (int)(max_y/refineogm_resolution + refineogm_offset_y/refineogm_resolution) + 1;
        for (int i = min_row; i < max_row; ++i)
        {
          for (int j = min_col; j < max_col; ++j)
          {
            int rigid_index = i * refineogmwidth_cell + j;
            if(rigid_refined_ogm[rigid_index].type == RIGIDNOPASSABLE)
            {
              rigid_refined_ogm[rigid_index].type = MOVINGOBJECT;
            }
          }
        }
      }
    }
  }
  if (0)
  {
    for (int m=0; m<moving_object_vector_send.size(); m++)
    {
      MovingObject temp_object = moving_object_vector_send.at(m);
      if(temp_object.is_updated)
      {
        show_result.ShowObjectCubic(cloud_viewer_, temp_object.shape, m, 1.0, 0.0, 0.0);
        if (1)
        {
          show_result.Show_word3D(cloud_viewer_, temp_object, m, 0,1.0,1.0);
        }
      }
    }
  }
  if (0)
  {
    for (int i = 0; i < polarogm_angle_cell; ++i)
    {
      float temp_angle = (i+0.5)*polarogm_angle_resolution*pi/180;
      pcl::PointXYZI pt1, pt2;
      pt1.x = 0 ;
      pt1.y = 0 ;
      pt1.z = 0;
      pt2.x = 60*cos(temp_angle);
      pt2.y = -60*sin(temp_angle);
      pt2.z = 60*polar_fit_line[i].a + polar_fit_line[i].c;
      char name_line[100];
      sprintf(name_line, "fitline%d", i);
      cloud_viewer_->addLine(pt1, pt2, 1.0, 0, 1.0, name_line);
      i++;
    }
  }
  if (0)
  {
    for (int i = 0; i < 7; ++i)
    {
      pcl::ModelCoefficients coefficients/*(new pcl::ModelCoefficients)*/;
      coefficients.values.resize(3);
      coefficients.values[0] = 0;
      coefficients.values[1] = 0;
      coefficients.values[2] = i*10;
      char name_circle[50];
      sprintf(name_circle, "bcircle%d", i);
      cloud_viewer_->addCircle(coefficients, name_circle);
      //cloud_viewer_->addCircle(coefficients,name,0)
    }

  }
  if(1)
  {
    pcl::PointCloud<pcl::PointXYZI>::Ptr  cloud_ground(new pcl::PointCloud<pcl::PointXYZI>);
    pcl::PointCloud<pcl::PointXYZI>::Ptr  cloud_nopassable(new pcl::PointCloud<pcl::PointXYZI>);
    pcl::PointCloud<pcl::PointXYZI>::Ptr  cloud_target(new pcl::PointCloud<pcl::PointXYZI>);
    //for(int k=0;k<lidarpropertys.size();k++)
    {
      pcl::PointCloud<pcl::PointXYZI>::Ptr  cloud_1(new pcl::PointCloud<pcl::PointXYZI>);
      cloud_1 = cloud_input;
      for (int i = 0; i < cloud_1->points.size(); ++i)
      {
        int point_id = i;
        pcl::PointXYZI newpoint = cloud_1->points[point_id];
        newpoint.y = newpoint.y -  V_OFFSET_Y;

        float x = cloud_1->points[point_id].x;
        float y = cloud_1->points[point_id].y;
        float z = cloud_1->points[point_id].z;
        int intensity = cloud_1->points[point_id].intensity;
        float dis_xy = sqrt(x*x + y*y);
        float azimuth = BaseFunction::Angle_atan2( x, y);
        float newy = y + refineogm_offset_y - V_OFFSET_Y ;

        if (!(fabs(x)<2.0 && fabs(y)<4.5)
            && x>-refineogm_width/2 && x<refineogm_width/2 && newy>0 && newy < refineogm_height)
        {
          int angle_col = (int)(azimuth / polarogm_angle_resolution);
          int radius_row = (int)(dis_xy / polarogm_radius_resolution);
          int polar_index = radius_row * polarogm_angle_cell + angle_col;

          int col = (int) ((x + refineogm_width / 2) / refineogm_resolution);
          int row = (int) (newy / refineogm_resolution);
          int rigid_index = row * refineogmwidth_cell + col;
          float delta_z = z - polar_ogm[polar_index].ground_z;
          //                    if (dis_xy < 10)
            //                    {
            //                        if (polar_ogm[polar_index].type == GROUND)
              //                        {
          //                            cloud_ground->points.push_back(newpoint);
          //                        } else
          //                        {
          //                           // cloud_nopassable->points.push_back(newpoint);
          //
          //                            if (fabs(delta_z)<0.2)
          //                            {
          //                                cloud_ground->points.push_back(newpoint);
          //                            } else
          //                            {
          //                                cloud_nopassable->points.push_back(newpoint);
          //                            }
          //                        }
          //                    }

          if (rigid_index<refineogmcell_size && col>0 && col<refineogmwidth_cell && row>0 && row<refineogmwidth_cell)
          {
            if (rigid_refined_ogm[rigid_index].type == GROUND)
              cloud_ground->points.push_back(newpoint);

            if (rigid_refined_ogm[rigid_index].type == RIGIDNOPASSABLE)
              cloud_nopassable->points.push_back(newpoint);

            if (rigid_refined_ogm[rigid_index].type == MOVINGOBJECT)
              cloud_target->points.push_back(newpoint);

          }
        }
      }

    }
    char cloud_name[50];
    if(cloud_ground->points.size()>0)
    {
      memset( cloud_name, 0 , 50);
      sprintf( cloud_name, "cloud_ground");
      ShowViewerCloudPoints( cloud_viewer_, cloud_ground, cloud_name, 125, 125, 125 );
    }
    if(cloud_nopassable->points.size()>0)
    {
      memset( cloud_name, 0 , 50);
      sprintf( cloud_name, "cloud_nopassable");
      ShowViewerCloudPoints( cloud_viewer_, cloud_nopassable, cloud_name, 0, 0, 255 );
    }
    if(cloud_target->points.size()>0)
    {
      memset( cloud_name, 0 , 50);
      sprintf( cloud_name, "cloud_target");
      ShowViewerCloudPoints( cloud_viewer_, cloud_target, cloud_name, 255, 0, 0 );
    }
  }
  cout<< " t_show_3D: " << t_show_3D.elapsed() << endl;
}

//***************************** show function ***********************//
void MovingTargetTrack::ShowViewerCloudPoints( boost::shared_ptr<PCLVisualizer> cloud_viewer_,
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_, char* cloudname, double red_, double green_, double blue_ )
{
  if ( cloud_->size()>0 )
  {
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZI> cloudHandler( cloud_, red_, green_, blue_ );
    if (!cloud_viewer_->updatePointCloud(cloud_,cloudHandler, cloudname))
      cloud_viewer_->addPointCloud(cloud_, cloudHandler, cloudname);
  }
}

}
