# anm_msgs

## Overview

The anm_msgs package contains custom ROS messages used in the autonomoose
software stack. These message definitions can be found under `anm_msgs/msg`.
